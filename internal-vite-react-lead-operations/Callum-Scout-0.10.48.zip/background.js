importScripts("config.js");
importScripts("convex-client.js");

const REFRESH_ALARM = "refresh-lead-total";
const CONNECTIONS_URL =
  "https://www.linkedin.com/mynetwork/invite-connect/connections/";
const SENT_INVITATIONS_URL =
  "https://www.linkedin.com/mynetwork/invitation-manager/sent/";
const AUTO_LEAD_RUN_STATE_KEY = "autoLeadRunState";
const AUTOMATION_HOME_URL = chrome.runtime.getURL("automation.html");
const AUTOMATION_GROUP_TITLE = "CALLUM AUTOMATION";
const ACTIVE_RUN_STATUSES = new Set(["running", "pausing"]);
const CONNECTION_COMPLETION_RETRY_DELAYS_MS = [0, 750, 2_000];
const CONNECTION_STATE_MAX_ATTEMPTS = 3;
const CONNECTION_STATE_RETRY_DELAYS_MS = [2_000, 4_000];
const CONNECTION_NOTE_MAX_ATTEMPTS = 2;
const CONNECTION_NOTE_RETRY_DELAY_MS = 1_500;
const LINKEDIN_TAB_LOAD_TIMEOUT_MS = 90_000;
const LINKEDIN_OPTIONAL_TAB_LOAD_TIMEOUT_MS = 30_000;
const LINKEDIN_TAB_READY_PROBE_MS = 1_000;
const UNCERTAIN_INVITATION_ERROR =
  "The connection request could not be confirmed. Check LinkedIn Pending before this lead is retried; ask your manager to review it.";
const AUTOMATION_KEEP_AWAKE_LEVEL = "display";
const DEFAULT_CONNECTION_REVIEW_LOOKBACK_DAYS = 30;
const ALLOWED_CONNECTION_REVIEW_LOOKBACK_DAYS = new Set([7, 30, 90, 183]);

let workflowPromise = null;
let manualConnectionReviewPromise = null;
let workflowControlRequest = null;
let activeRunId = null;
let activeWorkflowTabId = null;
let activeAutomationWindowId = null;
let runStateInitializationPromise = null;
let automationKeepAwakeActive = false;
let badgeRefreshPromise = null;

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(REFRESH_ALARM, { periodInMinutes: 30 });
  void initializeExtensionDefaults();
  void ensureAutoLeadRunState();
  refreshBadgeInBackground();
});

chrome.runtime.onStartup.addListener(() => {
  void initializeExtensionDefaults();
  void ensureAutoLeadRunState();
  refreshBadgeInBackground();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === REFRESH_ALARM) refreshBadgeInBackground();
});

chrome.windows.onRemoved.addListener((windowId) => {
  if (
    windowId === activeAutomationWindowId &&
    workflowPromise &&
    !workflowControlRequest
  ) {
    workflowControlRequest = {
      runId: activeRunId,
      action: "pause",
      reason:
        "The automation window was closed. The run paused safely; Resume will open a protected window and continue.",
    };
    void pauseRunAfterAutomationWindowClosed();
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (
    tabId !== activeWorkflowTabId ||
    !workflowPromise ||
    workflowControlRequest
  ) {
    return;
  }
  void requestWorkflowControl("pause", {
    reason:
      "The automation tab was closed. The run paused safely; Resume will open a protected tab and continue.",
  }).catch((error) => {
    console.warn(
      "Could not pause after the automation tab closed:",
      cleanError(error),
    );
  });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "REFRESH_SCOUT_DASHBOARD") {
    reconcileLocallyConfirmedConnectionRequests()
      .catch((error) => {
        console.warn(
          "Could not reconcile locally confirmed requests:",
          cleanError(error),
        );
      })
      .then(() => updateBadge({ cachedForMs: Math.min(30_000, Math.max(0, Number(message.cachedForMs) || 0)) }))
      .then((dashboard) => sendResponse({ ok: true, dashboard }))
      .catch((error) => sendResponse({ ok: false, error: cleanError(error) }));
    return true;
  }

  if (message?.type === "START_AUTO_LEAD") {
    startDailyWorkflow(message.leadId, { resume: false })
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: cleanError(error) }));
    return true;
  }

  if (message?.type === "RETRY_FAILED_LEADS") {
    startDailyWorkflow(null, { resume: false, retryFailedOnly: true })
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: cleanError(error) }));
    return true;
  }

  if (message?.type === "CHECK_ACCEPTED_CONNECTIONS") {
    checkAcceptedConnectionsManually()
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: cleanError(error) }));
    return true;
  }

  if (message?.type === "GET_AUTO_LEAD_RUN_STATE") {
    getAutoLeadRunState()
      .then((state) => sendResponse({ ok: true, state }))
      .catch((error) => sendResponse({ ok: false, error: cleanError(error) }));
    return true;
  }

  if (message?.type === "PAUSE_AUTO_LEAD") {
    requestWorkflowControl("pause")
      .then((state) => sendResponse({ ok: true, state }))
      .catch((error) => sendResponse({ ok: false, error: cleanError(error) }));
    return true;
  }

  if (message?.type === "RESUME_AUTO_LEAD") {
    resumeDailyWorkflow()
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: cleanError(error) }));
    return true;
  }

  if (message?.type === "STOP_AUTO_LEAD") {
    requestWorkflowControl("stop")
      .then((state) => sendResponse({ ok: true, state }))
      .catch((error) => sendResponse({ ok: false, error: cleanError(error) }));
    return true;
  }

  if (message?.type === "AUTO_WITHDRAW_OLD_REQUESTS") {
    autoWithdrawOldRequests()
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: cleanError(error) }));
    return true;
  }

  return false;
});

async function initializeExtensionDefaults() {
  const current = await chrome.storage.local.get([
    "validateBeforeCommenting",
    "connectionReviewLookbackDays",
  ]);
  const defaults = {};
  if (current.validateBeforeCommenting === undefined) {
    defaults.validateBeforeCommenting = false;
  }
  if (current.connectionReviewLookbackDays === undefined) {
    defaults.connectionReviewLookbackDays = DEFAULT_CONNECTION_REVIEW_LOOKBACK_DAYS;
  }
  if (Object.keys(defaults).length > 0) await chrome.storage.local.set(defaults);
  await chrome.storage.local.remove(["temporaryLeadTest", "invitationNote"]);
  await chrome.storage.local.remove([
    "linkedInPremium",
    "linkedInPremiumCheckedAt",
    "linkedInPremiumEvidence",
  ]);
}

async function startDailyWorkflow(
  specificLeadId,
  { resume = false, retryFailedOnly = false } = {},
) {
  await ensureAutoLeadRunState();
  if (manualConnectionReviewPromise) {
    throw new Error(
      "Wait for the accepted connection check to finish before starting today’s automation.",
    );
  }
  if (workflowPromise) {
    const state = await readAutoLeadRunState();
    return { status: state.status, state };
  }

  let previousState = await readAutoLeadRunState();
  previousState = await reconcileLocallyConfirmedConnectionRequests(
    previousState,
  );
  if (resume && !["paused", "failed"].includes(previousState.status)) {
    throw new Error("This run is not paused or failed, so there is nothing to resume.");
  }
  if (!resume && previousState.status === "paused") {
    throw new Error("This run is paused. Resume it or stop it before starting again.");
  }

  const resolvedSpecificLeadId = specificLeadId || null;
  const resolvedRetryFailedOnly = resume
    ? previousState.retryFailedOnly === true
    : retryFailedOnly === true;

  const runId = resume ? previousState.runId : createRunId();
  const inheritedPendingRequests = collectLocallyConfirmedConnectionRequests(
    previousState,
  );
  const progress = resume
    ? normalizeRunProgress(previousState.progress)
    : defaultRunProgress();
  if (!resume && inheritedPendingRequests.length > 0) {
    progress.pendingConnectionRequests = inheritedPendingRequests;
  }
  const runContext = {
    runId,
    resume,
    retryFailedOnly: resolvedRetryFailedOnly,
    progress,
    automationWindowId: null,
    automationHomeTabId: null,
    automationTabGroupId: null,
  };
  const startedAt = resume
    ? Number(previousState.startedAt || Date.now())
    : Date.now();
  workflowControlRequest = null;
  const automationContext = await prepareAutomationWindow(
    runContext,
    resume ? previousState : null,
    resume ? null : previousState,
  );
  Object.assign(runContext, automationContext);
  activeRunId = runId;
  activeAutomationWindowId = runContext.automationWindowId;
  try {
    requestAutomationKeepAwake();
    await writeAutoLeadRunState({
      ...(resume ? previousState : defaultAutoLeadRunState()),
      status: "running",
      runId,
      specificLeadId: resume
        ? previousState.specificLeadId || null
        : resolvedSpecificLeadId,
      retryFailedOnly: resolvedRetryFailedOnly,
      startedAt,
      resumedAt: resume ? Date.now() : null,
      pausedAt: null,
      pauseDetails: null,
      lastLeadIssue: null,
      stoppedAt: null,
      completedAt: null,
      phase: resume ? previousState.phase || "preparing" : "preparing",
      message: resume
        ? "Resuming from the last completed step..."
        : resolvedRetryFailedOnly
          ? "Preparing to retry failed leads..."
          : "Preparing today’s work...",
      currentLead: resume ? previousState.currentLead || null : null,
      automationWindowId: runContext.automationWindowId,
      automationHomeTabId: runContext.automationHomeTabId,
      automationTabGroupId: runContext.automationTabGroupId,
      progress: runContext.progress,
      result: null,
      error: null,
    });
  } catch (error) {
    activeRunId = null;
    activeAutomationWindowId = null;
    releaseAutomationKeepAwake();
    await closeManagedAutomationWindow(
      runContext.automationWindowId,
      runContext.automationHomeTabId,
    ).catch(() => {});
    throw error;
  }

  workflowPromise = runDailyWorkflow(
    resume ? previousState.specificLeadId || null : resolvedSpecificLeadId,
    runContext,
  )
    .then(async (result) => {
      const state = await updateActiveRunState(runContext, {
        status: "completed",
        phase: "completed",
        message: resolvedRetryFailedOnly
          ? result.summary.failedLeads.length > 0
            ? `Retry finished. ${result.summary.failedLeads.length} lead(s) still need attention.`
            : "Failed lead retry is complete."
          : result.summary.failedLeads.length > 0
            ? `Today’s work is complete. ${result.summary.failedLeads.length} lead(s) need attention and can be retried later.`
            : "Today’s work is complete.",
        currentLead: null,
        completedAt: Date.now(),
        progress: result.progress,
        result: result.summary,
      });
      return { status: "completed", result: result.summary, state };
    })
    .catch(async (error) => {
      let requestedControl = getRequestedWorkflowControl(runContext);
      if ((isLinkedInAccessInterruptionError(error) || isRecoverableServiceError(error)) && !requestedControl) {
        const interruptedState = await readAutoLeadRunState();
        await requestWorkflowControl("pause", {
          reason: cleanError(error),
          pauseDetails: {
            kind: error.kind || "service",
            leadName: interruptedState.currentLead?.fullName || "",
            stage: error.stage || interruptedState.phase || "unknown",
            pageUrl: safeLinkedInDiagnosticUrl(error.pageUrl),
            expectedUrl: safeLinkedInDiagnosticUrl(error.expectedUrl),
            occurredAt: error.occurredAt || Date.now(),
          },
        });
        requestedControl = "pause";
      }
      if (isWorkflowControlError(error) || requestedControl) {
        const control = error.control || requestedControl;
        const state = await finalizeControlledRun(runContext, control);
        return { status: control === "pause" ? "paused" : "stopped", state };
      }
      const state = await updateActiveRunState(runContext, {
        status: "failed",
        phase: "failed",
        message: friendlyWorkflowError(error),
        currentLead: null,
        completedAt: Date.now(),
        error: cleanError(error),
      });
      console.warn("Callum Scout run stopped:", cleanError(error));
      return { status: "failed", error: cleanError(error), state };
    })
    .finally(() => {
      workflowPromise = null;
      workflowControlRequest = null;
      activeRunId = null;
      activeWorkflowTabId = null;
      activeAutomationWindowId = null;
      releaseAutomationKeepAwake();
    });
  const state = await readAutoLeadRunState();
  return { status: state.status, state };
}

async function resumeDailyWorkflow() {
  if (workflowPromise) {
    const activeState = await getAutoLeadRunState();
    if (ACTIVE_RUN_STATUSES.has(activeState.status)) {
      return { status: activeState.status, state: activeState };
    }
    await workflowPromise;
  }
  const state = await getAutoLeadRunState();
  if (!['paused', 'failed'].includes(state.status)) {
    throw new Error("This run is not paused or failed, so there is nothing to resume.");
  }
  const storedLeadId = String(state.specificLeadId || "").trim();
  const specificLeadId = isLeadId(storedLeadId) ? storedLeadId : null;
  if (state.specificLeadId && !specificLeadId) {
    await writeAutoLeadRunState({
      ...state,
      specificLeadId: null,
      retryFailedOnly: false,
      progress: defaultRunProgress(),
      currentLead: null,
      phase: "preparing",
      message: "The previous lead selection was invalid. Retrying as a normal run.",
      error: null,
    });
  }
  return startDailyWorkflow(specificLeadId, {
    resume: true,
    retryFailedOnly: state.retryFailedOnly === true,
  });
}

async function runDailyWorkflow(specificLeadId, runContext) {
  const progress = runContext.progress;
  const isolatedLeadRun = Boolean(specificLeadId);
  const retryFailedOnly = runContext.retryFailedOnly === true;
  const skipDailyMaintenance = isolatedLeadRun || retryFailedOnly;
  throwIfWorkflowControlled(runContext);
  await updateRunProgress(runContext, progress, {
    phase: "preparing",
    message: runContext.resume
      ? "Checking the saved run before continuing..."
      : "Checking today’s limits...",
  });
  let dashboard = await ScoutApi.authenticatedAction("scouts:getDashboard");
  if (!dashboard.settings?.onboardingCompleted) {
    throw new Error("Finish setup before you start.");
  }

  let autoWithdraw = progress.autoWithdraw;
  if (!skipDailyMaintenance && !progress.autoWithdrawComplete) {
    await updateRunProgress(runContext, progress, {
      phase: "syncing_sent_invitations",
      message: "Syncing sent connection requests...",
      currentLead: null,
    });
    try {
      autoWithdraw = await autoWithdrawOldRequests(runContext);
    } catch (error) {
      if (isWorkflowControlError(error) || isLinkedInAccessInterruptionError(error)) throw error;
      throw new Error(`Sent invitation sync failed: ${cleanError(error)}`);
    }
    progress.autoWithdraw = autoWithdraw;
    progress.autoWithdrawComplete = true;
    await checkpointRun(runContext, progress, {
      phase: "reviewing_connections",
      message: "Syncing accepted connections...",
      currentLead: null,
    });
  }

  let review = progress.review;
  if (skipDailyMaintenance) {
    if (!progress.reviewComplete) {
      review = emptyConnectionReview();
      progress.review = review;
      progress.reviewComplete = true;
    }
    if (!progress.autoWithdrawComplete) {
      progress.autoWithdraw = { withdrawnCount: 0 };
      progress.autoWithdrawComplete = true;
    }
    await checkpointRun(runContext, progress, {
      phase: "working_leads",
      message: retryFailedOnly
        ? "Retry mode: only failed leads will be processed."
        : "Manual mode: only the selected lead will be processed.",
      currentLead: null,
    });
  } else if (!progress.reviewComplete) {
    await updateRunProgress(runContext, progress, {
      phase: "reviewing_connections",
      message: "Syncing accepted connections and contact details...",
    });
    review = await reviewAcceptedConnections(dashboard, runContext, {
      allowDeferredScan: true,
    });
    progress.review = review;
    progress.reviewComplete = true;
    await chrome.storage.local.set({
      lastAcceptedConnectionReview: {
        ...review,
        checkedAt: Date.now(),
        source: "daily",
        connectionWindowKeptOpen: false,
      },
    });
    await checkpointRun(runContext, progress, {
      phase: "working_leads",
      message: review.deferred
        ? "Connections check postponed. Continuing with today’s leads..."
        : "Starting today’s leads...",
      currentLead: null,
    });
  }

  dashboard = await ScoutApi.authenticatedAction("scouts:getDashboard");
  if (progress.targetRequests === null) {
    progress.targetRequests = specificLeadId
      ? 1
      : retryFailedOnly
        ? Math.min(dashboard.counts.retryableFailed ?? dashboard.counts.failed, dashboard.usage.requestRemaining)
        : dashboard.usage.requestRemaining;
  } else if (!specificLeadId) {
    progress.targetRequests = Math.min(
      progress.targetRequests,
      progress.requestsSent + dashboard.usage.requestRemaining,
    );
  }
  const availableRequestSlots = progress.targetRequests;
  if (progress.timedLeads > 0) refreshRunEta(progress);
  const results = progress.results;
  const failedLeads = progress.failedLeads;
  const pendingConnectionLeadIds = new Set(
    collectLocallyConfirmedConnectionRequests({ progress }).map(
      (request) => request.leadId,
    ),
  );
  const attemptedLeadIds = new Set([
    ...progress.results.map((result) => result?.leadId).filter(Boolean),
    ...progress.failedLeads.map((result) => result?.leadId).filter(Boolean),
    ...pendingConnectionLeadIds,
  ]);
  let resumeExistingLead = runContext.resume;
  let consecutiveUnreadableLeads = 0;
  let consecutiveConnectionStateFailures = 0;
  if (specificLeadId && pendingConnectionLeadIds.has(specificLeadId)) {
    progress.processedLeads = Math.max(progress.processedLeads, 1);
  }

  for (
    let index = progress.processedLeads;
    progress.requestsSent < availableRequestSlots;
    index++
  ) {
    throwIfWorkflowControlled(runContext);
    let lead;
    if (specificLeadId && index === 0) {
      lead = await ScoutApi.authenticatedAction("scouts:claimNextLead", {
        leadId: specificLeadId,
      });
      if (!lead) {
        throw new Error(
          "This lead is no longer available. Refresh the extension and try again.",
        );
      }
    } else {
      lead = await ScoutApi.authenticatedAction("scouts:claimNextLead", {
        excludeLeadIds: [...attemptedLeadIds],
        resumeExisting: retryFailedOnly ? false : resumeExistingLead,
        failedOnly: retryFailedOnly,
      });
      resumeExistingLead = false;
    }
    if (!lead?.linkedinUrl) break;
    attemptedLeadIds.add(lead.id);

    const leadStartedAt = Date.now();
    await checkpointRun(runContext, progress, {
      phase: lead.status === "engaged" ? "connecting" : "engaging",
      message:
        lead.status === "engaged"
          ? `Resuming ${lead.fullName} at the connection step...`
          : `Working on ${lead.fullName}...`,
      currentLead: {
        id: lead.id,
        fullName: lead.fullName,
        status: lead.status || "viewed",
      },
    });

    let connectionSyncPending = false;
    let deferredIssueMessage = null;
    try {
      const workflowResult = await runLeadWorkflow(
        lead,
        dashboard.settings,
        dashboard.usage,
        runContext,
        progress,
      );
      results.push(workflowResult);
      if (workflowResult.status === "connection_requested") {
        progress.requestsSent += 1;
      }
      consecutiveUnreadableLeads = 0;
      consecutiveConnectionStateFailures = 0;
    } catch (error) {
      if (isWorkflowControlError(error)) throw error;
      const deferUnreadableLead = canDeferUnreadableLead(error);
      if (isLinkedInAccessInterruptionError(error) && !deferUnreadableLead) {
        if (error.requestOutcomeUncertain === true) {
          await deferLeadForReview(lead, error, runContext, failedLeads);
          progress.processedLeads += 1;
          recordCompletedLeadTiming(progress, Date.now() - leadStartedAt);
          await updateRunProgress(runContext, progress);
        }
        throw error;
      }
      const message = cleanError(error);
      if (deferUnreadableLead || error?.requestOutcomeUncertain === true) {
        consecutiveConnectionStateFailures = 0;
        // Keep the assignment and confirmed comment receipts. A known-safe
        // page failure can be retried later; an unconfirmed invitation is
        // held from *all* automatic retries until Pending is reviewed.
        await deferLeadForReview(lead, error, runContext, failedLeads);
        deferredIssueMessage = error.requestOutcomeUncertain === true
          ? "The invitation could not be confirmed. This lead needs a Pending check; continuing with the next one..."
          : "That LinkedIn page did not load. The lead was saved for later; trying the next one...";
        consecutiveUnreadableLeads += 1;
        if (!deferUnreadableLead) consecutiveUnreadableLeads = 0;
      } else {
        consecutiveUnreadableLeads = 0;
        consecutiveConnectionStateFailures = error?.code === "CONNECTION_STATE_UNCONFIRMED"
          ? consecutiveConnectionStateFailures + 1
          : 0;
        // Stop a service/quota failure here instead of burning through every lead.
        if (!error?.requestSubmitted && isRecoverableServiceError(error)) throw error;
        const requestSent = error?.requestSubmitted === true;
        if (requestSent) {
          progress.requestsSent += 1;
          connectionSyncPending = error?.persistencePending === true;
          if (connectionSyncPending) {
            pendingConnectionLeadIds.add(lead.id);
            progress.pendingConnectionRequests = upsertPendingConnectionRequest(
              progress.pendingConnectionRequests,
              {
                leadId: lead.id,
                leadName: lead.fullName,
                profileUrl: error?.profileUrl || lead.linkedinUrl,
                confirmedAt: Date.now(),
              },
            );
          }
          results.push({
            leadId: lead.id,
            leadName: lead.fullName,
            status: connectionSyncPending
              ? "connection_requested_pending_sync"
              : "connection_requested",
            profileUrl: error?.profileUrl || lead.linkedinUrl,
            engagedCount: error?.engagedCount ?? 0,
          });
        } else if (error?.knownConnection === true) {
          await ScoutApi.authenticatedAction("scouts:reportError", {
            leadId: lead.id,
            message,
          }).catch(() => {});
          results.push({
            leadId: lead.id,
            leadName: lead.fullName,
            status: "accepted_contact_check_failed",
            profileUrl: error?.profileUrl || lead.linkedinUrl,
            email: null,
            connectionAlreadyPresent: true,
            message,
          });
          failedLeads.push({
            leadId: lead.id,
            leadName: lead.fullName,
            message,
            requestSent: false,
            connectionAlreadyPresent: true,
          });
        } else {
          const status =
            /no recent posts|no supported post permalink/i.test(message)
              ? "skipped"
              : "failed";
          try {
            await ScoutApi.authenticatedAction("scouts:updateLeadStatus", {
              leadId: lead.id,
              status,
              email: null,
              error: message,
            });
          } catch (statusError) {
            await ScoutApi.authenticatedAction("scouts:reportError", {
              leadId: lead.id,
              message,
            }).catch(() => {});
            console.warn(
              "Could not record the failed lead status:",
              cleanError(statusError),
            );
          }
          failedLeads.push({
            leadId: lead.id,
            leadName: lead.fullName,
            message,
            requestSent: false,
          });
          if (specificLeadId) throw new Error(message);
        }
      }
    }
    progress.processedLeads += 1;
    recordCompletedLeadTiming(progress, Date.now() - leadStartedAt);
    await checkpointRun(runContext, progress, {
      phase: "working_leads",
      message: deferredIssueMessage || "Lead finished. Continuing toward today’s request goal...",
      currentLead: null,
    });
    if (consecutiveUnreadableLeads >= 2) {
      const interruption = new LinkedInAccessInterruptionError("page_unavailable", {
        stage: "Multiple LinkedIn pages failed to load",
      });
      interruption.message = "LinkedIn did not load on two leads in a row. Both were saved for later. Check that LinkedIn opens normally, then press Resume.";
      throw interruption;
    }
    if (consecutiveConnectionStateFailures >= 2) {
      throw new LinkedInAccessInterruptionError("connection_actions_unavailable", {
        stage: "Connection actions unavailable on two profiles",
      });
    }
    dashboard = await ScoutApi.authenticatedAction("scouts:getDashboard");
    if (specificLeadId) break;
  }

  await updateBadge({ dashboard });
  const knownConnectionResults = results.filter(
    (result) => result?.connectionAlreadyPresent === true,
  );
  const summary = {
    reviewedConnections: review.reviewed,
    acceptedMatched: review.acceptedMatched,
    contactsChecked: review.contactsChecked + knownConnectionResults.length,
    emailsCollected:
      review.emailsCollected +
      knownConnectionResults.filter((result) => result?.email).length,
    withdrawnCount: Number(autoWithdraw?.withdrawnCount || 0),
    requestsSent: progress.requestsSent,
    failedLeads,
    leads: results,
    requestLimitReached: dashboard.usage.requestRemaining <= 0,
  };
  return { summary, progress };
}

async function deferLeadForReview(lead, error, runContext, failedLeads) {
  const invitationUnconfirmed = error.requestOutcomeUncertain === true;
  const message = invitationUnconfirmed
    ? UNCERTAIN_INVITATION_ERROR
    : "LinkedIn did not finish loading this lead. Saved for a later retry.";
  await ScoutApi.authenticatedAction("scouts:updateLeadStatus", {
    leadId: lead.id,
    status: "failed",
    email: null,
    error: message,
  });
  failedLeads.push({
    leadId: lead.id,
    leadName: lead.fullName,
    message,
    requestSent: false,
    stage: error.stage || "LinkedIn page",
    pageUrl: safeLinkedInDiagnosticUrl(error.pageUrl),
  });
  await updateActiveRunState(runContext, {
    lastLeadIssue: {
      kind: invitationUnconfirmed ? "invitation_unconfirmed" : error.kind || "page_unavailable",
      leadName: lead.fullName,
      stage: error.stage || "LinkedIn page",
      pageUrl: safeLinkedInDiagnosticUrl(error.pageUrl),
      expectedUrl: safeLinkedInDiagnosticUrl(error.expectedUrl),
      occurredAt: error.occurredAt || Date.now(),
    },
  });
}

function ensureAutoLeadRunState() {
  if (!runStateInitializationPromise) {
    runStateInitializationPromise = recoverAutoLeadRunState();
  }
  return runStateInitializationPromise;
}

async function recoverAutoLeadRunState() {
  const state = await readAutoLeadRunState();
  if (!workflowPromise) releaseAutomationKeepAwake();
  if (!state.runId) {
    return writeAutoLeadRunState(defaultAutoLeadRunState());
  }
  if (ACTIVE_RUN_STATUSES.has(state.status) && !workflowPromise) {
    return writeAutoLeadRunState({
      ...state,
      status: "paused",
      phase: "paused",
      pausedAt: Date.now(),
      message:
        "The extension paused this run safely. Resume to continue from the last completed step.",
    });
  }
  if (state.status === "failed" && !workflowPromise) {
    return writeAutoLeadRunState({
      ...state,
      status: "paused",
      phase: "paused",
      pausedAt: Date.now(),
      message: "The previous run failed before completion. Resume to retry it.",
    });
  }
  return state;
}

async function getAutoLeadRunState() {
  await ensureAutoLeadRunState();
  return readAutoLeadRunState();
}

async function readAutoLeadRunState() {
  const stored = await chrome.storage.local.get(AUTO_LEAD_RUN_STATE_KEY);
  return normalizeAutoLeadRunState(stored[AUTO_LEAD_RUN_STATE_KEY]);
}

async function writeAutoLeadRunState(state) {
  const next = normalizeAutoLeadRunState({
    ...state,
    updatedAt: Date.now(),
  });
  await chrome.storage.local.set({ [AUTO_LEAD_RUN_STATE_KEY]: next });
  return next;
}

async function updateActiveRunState(runContext, patch) {
  const current = await readAutoLeadRunState();
  if (current.runId !== runContext.runId) return current;
  if (current.status === "stopped" && patch.status !== "stopped") return current;
  return writeAutoLeadRunState({ ...current, ...patch });
}

async function updateRunProgress(runContext, progress, patch = {}) {
  return updateActiveRunState(runContext, {
    ...patch,
    progress: normalizeRunProgress(progress),
  });
}

async function checkpointRun(runContext, progress, patch = {}) {
  await updateRunProgress(runContext, progress, patch);
  throwIfWorkflowControlled(runContext);
}

function throwIfWorkflowControlled(runContext) {
  const control = getRequestedWorkflowControl(runContext);
  if (control) throw new WorkflowControlError(control);
}

function getRequestedWorkflowControl(runContext) {
  return workflowControlRequest?.runId === runContext.runId &&
    ["pause", "stop"].includes(workflowControlRequest.action)
    ? workflowControlRequest.action
    : null;
}

function isWorkflowControlError(error) {
  return (
    error instanceof WorkflowControlError ||
    error?.name === "WorkflowControlError"
  );
}

class WorkflowControlError extends Error {
  constructor(control) {
    super(control === "pause" ? "Run paused." : "Run stopped.");
    this.name = "WorkflowControlError";
    this.control = control;
  }
}

class LinkedInAccessInterruptionError extends Error {
  constructor(kind, details = {}) {
    super(
      kind === "page_unavailable"
        ? "The LinkedIn page could not be read. This lead was kept safe; check that LinkedIn opens normally."
        : kind === "connection_actions_unavailable"
        ? "LinkedIn did not show usable connection actions on two profiles. Scout paused to avoid checking more leads. Check whether Connect is visible on LinkedIn, then report the issue with a screenshot of the profile actions."
        : kind === "profile_link"
        ? "LinkedIn did not provide a verified profile link. Scout paused without skipping this lead. Please use Report Bug so support can check the link."
        : kind === "checkpoint"
        ? "LinkedIn opened a security check. Callum Scout paused instead of skipping more leads. Complete the LinkedIn check, then press Resume."
        : "LinkedIn opened a sign-in or access page. Scout paused safely. Open LinkedIn in this Chrome profile and check the page before pressing Resume. If it happens again, use Report Bug.",
    );
    this.name = "LinkedInAccessInterruptionError";
    this.kind = kind;
    this.pageUrl = safeLinkedInDiagnosticUrl(details.pageUrl);
    this.expectedUrl = safeLinkedInDiagnosticUrl(details.expectedUrl);
    this.stage = String(details.stage || "").slice(0, 200);
    this.occurredAt = Date.now();
  }
}

function safeLinkedInDiagnosticUrl(value) {
  try {
    const url = new URL(String(value));
    if (url.protocol !== "https:" || !/(^|\.)linkedin\.com$/i.test(url.hostname)) return "";
    // Never persist credentials, query parameters or fragments from redirects.
    return `${url.origin}${url.pathname}`.slice(0, 1000);
  } catch { return ""; }
}

function isLinkedInAccessInterruptionError(error) {
  return (
    error instanceof LinkedInAccessInterruptionError ||
    error?.name === "LinkedInAccessInterruptionError"
  );
}

function canDeferUnreadableLead(error) {
  return isLinkedInAccessInterruptionError(error) &&
    error.kind === "page_unavailable";
}

async function requestWorkflowControl(action, { reason = null, pauseDetails = null } = {}) {
  await ensureAutoLeadRunState();
  const state = await readAutoLeadRunState();
  if (action === "pause") {
    if (state.status === "paused" || state.status === "pausing") return state;
    if (state.status !== "running") return state;

    workflowControlRequest = { runId: state.runId, action: "pause", reason };
    const next = await writeAutoLeadRunState({
      ...state,
      status: workflowPromise ? "pausing" : "paused",
      phase: workflowPromise ? state.phase : "paused",
      pausedAt: workflowPromise ? null : Date.now(),
      pauseDetails,
      message: reason ||
        (workflowPromise
          ? "Pausing after the current safe step..."
          : "Paused. Resume to continue from the last completed step."),
    });
    if (activeWorkflowTabId) {
      await sendStatusToProtectedActiveTab(
        state,
        "Pausing after the current safe step...",
      );
    }
    return next;
  }

  if (action !== "stop") throw new Error("Unknown run control.");
  if (["idle", "completed", "stopped"].includes(state.status)) {
    releaseAutomationKeepAwake();
    return state;
  }

  workflowControlRequest = { runId: state.runId, action: "stop" };
  const automationWindowId = state.automationWindowId || activeAutomationWindowId;
  const automationHomeTabId = state.automationHomeTabId || null;
  const next = await writeAutoLeadRunState({
    ...state,
    status: "stopped",
    phase: "stopped",
    message: "Run stopped completely. Start again whenever you are ready.",
    specificLeadId: null,
    retryFailedOnly: false,
    currentLead: null,
    automationWindowId: null,
    automationHomeTabId: null,
    automationTabGroupId: null,
    progress: null,
    result: null,
    stoppedAt: Date.now(),
    completedAt: Date.now(),
  });
  if (activeWorkflowTabId && automationWindowId) {
    await sendStatusToProtectedActiveTab(state, "Stopped.");
  }
  activeAutomationWindowId = null;
  await closeManagedAutomationWindow(
    automationWindowId,
    automationHomeTabId,
  ).catch(() => {});
  return next;
}

function requestAutomationKeepAwake() {
  if (automationKeepAwakeActive || !chrome.power?.requestKeepAwake) return false;
  chrome.power.requestKeepAwake(AUTOMATION_KEEP_AWAKE_LEVEL);
  automationKeepAwakeActive = true;
  return true;
}

function releaseAutomationKeepAwake() {
  if (chrome.power?.releaseKeepAwake) {
    chrome.power.releaseKeepAwake();
  }
  automationKeepAwakeActive = false;
}

async function finalizeControlledRun(runContext, control) {
  const state = await readAutoLeadRunState();
  if (state.runId !== runContext.runId || state.status === "stopped") {
    return state;
  }
  if (control === "stop") {
    return writeAutoLeadRunState({
      ...state,
      status: "stopped",
      phase: "stopped",
      message: "Run stopped completely. Start again whenever you are ready.",
      specificLeadId: null,
      retryFailedOnly: false,
      currentLead: null,
      automationWindowId: null,
      automationHomeTabId: null,
      automationTabGroupId: null,
      progress: null,
      result: null,
      stoppedAt: Date.now(),
      completedAt: Date.now(),
    });
  }
  return writeAutoLeadRunState({
    ...state,
    status: "paused",
    phase: "paused",
    message: workflowControlRequest?.reason ||
      "Paused. Resume to continue from the last completed step.",
    pausedAt: Date.now(),
  });
}

function defaultAutoLeadRunState() {
  return {
    status: "idle",
    runId: null,
    specificLeadId: null,
    retryFailedOnly: false,
    startedAt: null,
    resumedAt: null,
    pausedAt: null,
    pauseDetails: null,
    stoppedAt: null,
    completedAt: null,
    updatedAt: Date.now(),
    phase: "idle",
    message: "Ready to start today’s work.",
    currentLead: null,
    automationWindowId: null,
    automationHomeTabId: null,
    automationTabGroupId: null,
    progress: null,
    result: null,
    error: null,
    lastLeadIssue: null,
  };
}

function defaultRunProgress() {
  return {
    reviewComplete: false,
    review: emptyConnectionReview(),
    autoWithdrawComplete: false,
    autoWithdraw: { withdrawnCount: 0 },
    targetRequests: null,
    processedLeads: 0,
    requestsSent: 0,
    timedLeads: 0,
    totalLeadDurationMs: 0,
    averageLeadDurationMs: null,
    estimatedRemainingLeads: null,
    estimatedRemainingMs: null,
    estimatedCompletionAt: null,
    results: [],
    failedLeads: [],
    pendingConnectionRequests: [],
  };
}

function normalizeRunProgress(value) {
  const fallback = defaultRunProgress();
  if (!value || typeof value !== "object") return fallback;
  return {
    reviewComplete: value.reviewComplete === true,
    review: {
      ...fallback.review,
      ...(value.review && typeof value.review === "object" ? value.review : {}),
    },
    autoWithdrawComplete: value.autoWithdrawComplete === true,
    autoWithdraw:
      value.autoWithdraw && typeof value.autoWithdraw === "object"
        ? value.autoWithdraw
        : fallback.autoWithdraw,
    targetRequests:
      value.targetRequests === null || value.targetRequests === undefined
        ? null
        : Math.max(0, Math.trunc(Number(value.targetRequests) || 0)),
    processedLeads: Math.max(0, Math.trunc(Number(value.processedLeads) || 0)),
    requestsSent: Math.max(0, Math.trunc(Number(value.requestsSent) || 0)),
    timedLeads: Math.max(0, Math.trunc(Number(value.timedLeads) || 0)),
    totalLeadDurationMs: Math.max(0, Number(value.totalLeadDurationMs) || 0),
    averageLeadDurationMs:
      Number(value.averageLeadDurationMs) > 0
        ? Number(value.averageLeadDurationMs)
        : null,
    estimatedRemainingLeads:
      value.estimatedRemainingLeads !== null &&
      value.estimatedRemainingLeads !== undefined &&
      Number.isFinite(Number(value.estimatedRemainingLeads))
        ? Math.max(0, Math.trunc(Number(value.estimatedRemainingLeads)))
        : null,
    estimatedRemainingMs:
      value.estimatedRemainingMs !== null &&
      value.estimatedRemainingMs !== undefined &&
      Number.isFinite(Number(value.estimatedRemainingMs))
        ? Math.max(0, Number(value.estimatedRemainingMs))
        : null,
    estimatedCompletionAt:
      Number(value.estimatedCompletionAt) > 0
        ? Number(value.estimatedCompletionAt)
        : null,
    results: Array.isArray(value.results) ? value.results : [],
    failedLeads: Array.isArray(value.failedLeads) ? value.failedLeads : [],
    pendingConnectionRequests: Array.isArray(value.pendingConnectionRequests)
      ? value.pendingConnectionRequests
      : [],
  };
}

function recordCompletedLeadTiming(progress, durationMs, now = Date.now()) {
  const safeDurationMs = Math.max(1_000, Number(durationMs) || 0);
  progress.timedLeads = Math.max(0, Number(progress.timedLeads) || 0) + 1;
  progress.totalLeadDurationMs =
    Math.max(0, Number(progress.totalLeadDurationMs) || 0) + safeDurationMs;
  progress.averageLeadDurationMs = Math.round(
    progress.totalLeadDurationMs / progress.timedLeads,
  );
  refreshRunEta(progress, now);
}

function refreshRunEta(progress, now = Date.now()) {
  const averageMs = Number(progress.averageLeadDurationMs) || 0;
  const targetRequests = Number(progress.targetRequests);
  if (averageMs <= 0 || !Number.isFinite(targetRequests)) {
    progress.estimatedRemainingLeads = null;
    progress.estimatedRemainingMs = null;
    progress.estimatedCompletionAt = null;
    return;
  }

  const requestsSent = Math.max(0, Number(progress.requestsSent) || 0);
  const processedLeads = Math.max(0, Number(progress.processedLeads) || 0);
  const remainingRequests = Math.max(0, targetRequests - requestsSent);
  const successRate =
    processedLeads > 0 && requestsSent > 0
      ? Math.max(0.1, Math.min(1, requestsSent / processedLeads))
      : 1;
  const remainingLeads = Math.ceil(remainingRequests / successRate);
  const remainingMs = Math.round(remainingLeads * averageMs);
  progress.estimatedRemainingLeads = remainingLeads;
  progress.estimatedRemainingMs = remainingMs;
  progress.estimatedCompletionAt = now + remainingMs;
}

function upsertPendingConnectionRequest(requests, request) {
  const next = Array.isArray(requests) ? [...requests] : [];
  const existingIndex = next.findIndex(
    (item) => item?.leadId === request.leadId,
  );
  if (existingIndex >= 0) next[existingIndex] = request;
  else next.push(request);
  return next;
}

function collectLocallyConfirmedConnectionRequests(state) {
  const progress = state?.progress || {};
  const result = state?.result || {};
  const candidates = [
    ...(Array.isArray(progress.pendingConnectionRequests)
      ? progress.pendingConnectionRequests
      : []),
    ...(Array.isArray(progress.failedLeads)
      ? progress.failedLeads.filter((lead) => lead?.requestSent === true)
      : []),
    ...(Array.isArray(result.failedLeads)
      ? result.failedLeads.filter((lead) => lead?.requestSent === true)
      : []),
  ];
  const unique = new Map();
  for (const candidate of candidates) {
    const leadId = String(candidate?.leadId || "").trim();
    if (!leadId || unique.has(leadId)) continue;
    unique.set(leadId, { ...candidate, leadId });
  }
  return [...unique.values()];
}

async function reconcileLocallyConfirmedConnectionRequests(state = null) {
  const current = state || (await readAutoLeadRunState());
  const confirmed = collectLocallyConfirmedConnectionRequests(current);
  if (confirmed.length === 0) return current;

  const reconciledLeadIds = new Set();
  for (const request of confirmed) {
    const args = { leadId: request.leadId };
    if (request.profileUrl) args.profileUrl = request.profileUrl;
    try {
      await completeConnectionRequestWithRetry(args);
      reconciledLeadIds.add(request.leadId);
    } catch (error) {
      console.warn(
        `Connection request sync is still pending for ${request.leadId}:`,
        cleanError(error),
      );
    }
  }
  if (reconciledLeadIds.size === 0) return current;

  const progress = current.progress
    ? normalizeRunProgress({
        ...current.progress,
        pendingConnectionRequests:
          current.progress.pendingConnectionRequests?.filter(
            (request) => !reconciledLeadIds.has(request?.leadId),
          ) || [],
        failedLeads:
          current.progress.failedLeads?.filter(
            (lead) =>
              !(
                lead?.requestSent === true &&
                reconciledLeadIds.has(lead?.leadId)
              ),
          ) || [],
      })
    : null;
  const result = current.result
    ? {
        ...current.result,
        failedLeads:
          current.result.failedLeads?.filter(
            (lead) =>
              !(
                lead?.requestSent === true &&
                reconciledLeadIds.has(lead?.leadId)
              ),
          ) || [],
      }
    : null;
  const recoveredFailedRun =
    current.status === "failed" &&
    current.progress?.failedLeads?.some(
      (lead) =>
        lead?.requestSent === true && reconciledLeadIds.has(lead?.leadId),
    ) &&
    (progress?.failedLeads?.length || 0) === 0;

  return writeAutoLeadRunState({
    ...current,
    status: recoveredFailedRun ? "completed" : current.status,
    phase: recoveredFailedRun ? "completed" : current.phase,
    message: recoveredFailedRun
      ? "The sent connection request is confirmed and synced."
      : current.message,
    error: recoveredFailedRun ? null : current.error,
    completedAt: recoveredFailedRun ? Date.now() : current.completedAt,
    progress,
    result,
  });
}

function normalizeAutoLeadRunState(value) {
  const fallback = defaultAutoLeadRunState();
  if (!value || typeof value !== "object") return fallback;
  const allowedStatuses = new Set([
    "idle",
    "running",
    "pausing",
    "paused",
    "stopped",
    "completed",
    "failed",
  ]);
  return {
    ...fallback,
    ...value,
    status: allowedStatuses.has(value.status) ? value.status : "idle",
    progress: value.progress ? normalizeRunProgress(value.progress) : null,
    currentLead:
      value.currentLead && typeof value.currentLead === "object"
        ? value.currentLead
        : null,
  };
}

function emptyConnectionReview() {
  return {
    reviewed: false,
    acceptedMatched: 0,
    contactsChecked: 0,
    emailsCollected: 0,
    connectionsScanned: 0,
  };
}

async function prepareAutomationWindow(
  runContext,
  resumeState = null,
  previousStateToClose = null,
) {
  if (resumeState) {
    const existing = await getManagedAutomationContext(resumeState).catch(
      () => null,
    );
    if (existing) {
      await chrome.windows.update(existing.automationWindowId, { focused: true });
      await chrome.tabs.update(existing.automationHomeTabId, { active: true });
      return existing;
    }
    await closeManagedAutomationWindow(
      resumeState.automationWindowId,
      resumeState.automationHomeTabId,
    ).catch(() => {});
  }

  if (previousStateToClose?.automationWindowId) {
    await closeManagedAutomationWindow(
      previousStateToClose.automationWindowId,
      previousStateToClose.automationHomeTabId,
    ).catch(() => {});
  }

  throwIfWorkflowControlled(runContext);
  const created = await chrome.windows.create({
    url: AUTOMATION_HOME_URL,
    type: "normal",
    focused: true,
    width: 1180,
    height: 820,
  });
  if (!created?.id) {
    throw new Error("We couldn’t open the dedicated automation window.");
  }
  const tabs = created.tabs?.length
    ? created.tabs
    : await chrome.tabs.query({ windowId: created.id });
  const homeTab = tabs.find(
    (tab) => tab.url === AUTOMATION_HOME_URL || tab.pendingUrl === AUTOMATION_HOME_URL,
  );
  if (!homeTab?.id) {
    await chrome.windows.remove(created.id).catch(() => {});
    throw new Error("The automation window opened without its status tab.");
  }
  try {
    const groupId = await chrome.tabs.group({
      tabIds: homeTab.id,
      createProperties: { windowId: created.id },
    });
    await styleAutomationTabGroup(groupId);
    return {
      automationWindowId: created.id,
      automationHomeTabId: homeTab.id,
      automationTabGroupId: groupId,
    };
  } catch (error) {
    await chrome.windows.remove(created.id).catch(() => {});
    throw error;
  }
}

async function getManagedAutomationContext(state) {
  const windowId = Number(state.automationWindowId);
  const homeTabId = Number(state.automationHomeTabId);
  if (!Number.isInteger(windowId) || !Number.isInteger(homeTabId)) return null;
  const window = await chrome.windows.get(windowId, { populate: true });
  const homeTab = window.tabs?.find((tab) => tab.id === homeTabId);
  if (!isManagedAutomationHomeTab(homeTab, windowId)) {
    return null;
  }

  let groupId = Number(state.automationTabGroupId);
  let group = Number.isInteger(groupId)
    ? await chrome.tabGroups.get(groupId).catch(() => null)
    : null;
  if (!group || group.windowId !== windowId) {
    groupId = Number(homeTab.groupId);
    group = Number.isInteger(groupId) && groupId >= 0
      ? await chrome.tabGroups.get(groupId).catch(() => null)
      : null;
    if (!group || group.windowId !== windowId) {
      groupId = await chrome.tabs.group({
        tabIds: homeTabId,
        createProperties: { windowId },
      });
    }
  }
  await styleAutomationTabGroup(groupId);
  const staleWorkerTabIds = (window.tabs || [])
    .filter((tab) => tab.id !== homeTabId && tab.groupId === groupId)
    .map((tab) => tab.id)
    .filter(Number.isInteger);
  if (staleWorkerTabIds.length > 0) {
    await chrome.tabs.remove(staleWorkerTabIds).catch(() => {});
  }
  return {
    automationWindowId: windowId,
    automationHomeTabId: homeTabId,
    automationTabGroupId: groupId,
  };
}

async function styleAutomationTabGroup(groupId) {
  await chrome.tabGroups.update(groupId, {
    title: AUTOMATION_GROUP_TITLE,
    color: "purple",
    collapsed: false,
  });
}

async function closeManagedAutomationWindow(windowId, homeTabId) {
  if (!Number.isInteger(Number(windowId)) || !Number.isInteger(Number(homeTabId))) {
    return false;
  }
  const homeTab = await chrome.tabs.get(Number(homeTabId)).catch(() => null);
  if (!isManagedAutomationHomeTab(homeTab, Number(windowId))) {
    return false;
  }
  await chrome.windows.remove(Number(windowId));
  return true;
}

async function createAutomationTab(runContext, url, { active = true } = {}) {
  throwIfWorkflowControlled(runContext);
  await assertAutomationWindow(runContext);
  let protectedGroupId = await ensureAutomationTabGroup(runContext);
  const tab = await chrome.tabs.create({
    windowId: runContext.automationWindowId,
    url,
    active,
  });
  if (!tab?.id) throw new Error("The automation tab did not open.");
  try {
    let groupId;
    try {
      groupId = await chrome.tabs.group({
        tabIds: tab.id,
        groupId: protectedGroupId,
      });
    } catch {
      protectedGroupId = await ensureAutomationTabGroup(runContext, {
        forceNew: true,
      });
      groupId = await chrome.tabs.group({
        tabIds: tab.id,
        groupId: protectedGroupId,
      });
    }
    if (groupId !== protectedGroupId) {
      throw new Error("The automation tab opened outside its protected group.");
    }
  } catch (error) {
    await chrome.tabs.remove(tab.id).catch(() => {});
    throw error;
  }
  setActiveWorkflowTab(runContext, tab.id);
  return tab;
}

async function ensureAutomationTabGroup(runContext, { forceNew = false } = {}) {
  await assertAutomationWindow(runContext);
  const windowId = Number(runContext.automationWindowId);
  const homeTabId = Number(runContext.automationHomeTabId);
  const homeTab = Number.isInteger(homeTabId)
    ? await chrome.tabs.get(homeTabId).catch(() => null)
    : null;
  if (!isManagedAutomationHomeTab(homeTab, windowId)) {
    throw new Error("The protected automation status tab is not available.");
  }

  let groupId = forceNew ? null : Number(runContext.automationTabGroupId);
  const existingGroup = Number.isInteger(groupId) && groupId >= 0
    ? await chrome.tabGroups.get(groupId).catch(() => null)
    : null;
  if (!existingGroup || existingGroup.windowId !== windowId) {
    groupId = await chrome.tabs.group({
      tabIds: homeTabId,
      createProperties: { windowId },
    });
    await styleAutomationTabGroup(groupId);
    runContext.automationTabGroupId = groupId;
    await updateActiveRunState(runContext, {
      automationTabGroupId: groupId,
      message:
        "The protected tab group was repaired automatically. Continuing safely...",
    });
  }
  return groupId;
}

async function assertAutomationWindow(runContext) {
  const windowId = Number(runContext.automationWindowId);
  if (!Number.isInteger(windowId) || windowId !== activeAutomationWindowId) {
    throw new Error("The dedicated automation window is not available.");
  }
  await chrome.windows.get(windowId);
}

async function assertAutomationTab(runContext, tabId) {
  await assertAutomationWindow(runContext);
  const tab = await chrome.tabs.get(tabId);
  if (!isProtectedAutomationTab(tab, runContext)) {
    throw new Error(
      "Automation stopped because its tab was moved outside the protected window.",
    );
  }
  return tab;
}

function isProtectedAutomationTab(tab, runContext) {
  return Boolean(
    tab &&
      tab.windowId === runContext.automationWindowId &&
      tab.groupId === runContext.automationTabGroupId,
  );
}

function isManagedAutomationHomeTab(tab, windowId) {
  return Boolean(
    tab &&
      tab.windowId === windowId &&
      (tab.url === AUTOMATION_HOME_URL ||
        tab.pendingUrl === AUTOMATION_HOME_URL),
  );
}

async function waitForAutomationContentScript(runContext, tabId) {
  await assertAutomationTab(runContext, tabId);
  const page = await waitForContentScript(tabId);
  await assertAutomationTab(runContext, tabId);
  const marker = await sendMessageToTab(tabId, {
    type: "SET_AUTOMATION_CONTEXT",
    runId: runContext.runId,
    groupTitle: AUTOMATION_GROUP_TITLE,
  });
  if (!marker?.ok) {
    throw new Error("We couldn’t mark the protected automation tab.");
  }
  return page;
}

async function sendAutomationMessageToTab(
  runContext,
  tabId,
  message,
  { retryOnClosedChannel = false, recoveryMessage = null } = {},
) {
  await assertAutomationTab(runContext, tabId);
  let response = await sendMessageToTab(tabId, message);
  if (
    retryOnClosedChannel &&
    isClosedMessageChannelError(response?.error)
  ) {
    await updateActiveRunState(runContext, {
      message:
        recoveryMessage ||
        "LinkedIn refreshed while Callum Scout was checking the page. Reconnecting safely...",
    });
    await waitForAutomationContentScript(runContext, tabId);
    await assertAutomationTab(runContext, tabId);
    response = await sendMessageToTab(tabId, message);
  }
  return response;
}

async function sendStatusToProtectedActiveTab(state, status) {
  if (!activeWorkflowTabId) return;
  const tab = await chrome.tabs.get(activeWorkflowTabId).catch(() => null);
  if (!isProtectedAutomationTab(tab, state)) return;
  await sendMessageToTab(activeWorkflowTabId, {
    type: "SHOW_AUTOMATION_STATUS",
    status,
  }).catch(() => {});
}

async function pauseRunAfterAutomationWindowClosed() {
  activeAutomationWindowId = null;
  const state = await requestWorkflowControl("pause", {
    reason:
      "The automation window was closed. The run paused safely; Resume will open a protected window and continue.",
  });
  if (state.runId) {
    await writeAutoLeadRunState({
      ...state,
      automationWindowId: null,
      automationHomeTabId: null,
      automationTabGroupId: null,
    });
  }
}

function createRunId() {
  return globalThis.crypto?.randomUUID?.() ||
    `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function isLeadId(value) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
    String(value || "").trim(),
  );
}

function setActiveWorkflowTab(runContext, tabId) {
  throwIfWorkflowControlled(runContext);
  activeWorkflowTabId = tabId;
}

function clearActiveWorkflowTab(tabId) {
  if (activeWorkflowTabId === tabId) activeWorkflowTabId = null;
}

async function reviewAcceptedConnections(
  dashboard,
  runContext,
  { forceReview = false, keepConnectionTab = false, collectContacts = true, allowDeferredScan = false } = {},
) {
  const empty = emptyConnectionReview();

  throwIfWorkflowControlled(runContext);
  const plan = await ScoutApi.authenticatedAction(
    "scouts:getConnectionReviewPlan",
  );
  if (!forceReview && !plan.shouldReview) {
    return { ...empty, notNeeded: true };
  }
  const lookbackDays = await readConnectionReviewLookbackDays();

  const tab = await createAutomationTab(runContext, CONNECTIONS_URL);
  if (!tab?.id) throw new Error("We couldn’t open your LinkedIn connections.");
  runContext.connectionReviewTabId = tab.id;
  let reviewResult;
  try {
    await waitForTabComplete(tab.id, {
      expectedUrl: CONNECTIONS_URL,
      stage: "LinkedIn connections page",
    });
    throwIfWorkflowControlled(runContext);
    await waitForAutomationContentScript(runContext, tab.id);
    let scan;
    try {
      scan = await sendAutomationMessageToTab(runContext, tab.id, {
        type: "SCAN_RECENT_CONNECTIONS",
        options: {
          checkpoint: plan.checkpoint,
          cutoffDate: plan.cutoffDate,
          lookbackDays,
          maxProfiles: 1_000,
        },
      });
    } catch (error) {
      if (isWorkflowControlError(error) || isLinkedInAccessInterruptionError(error)) {
        throw error;
      }
      scan = { ok: false, error: cleanError(error) };
    }
    throwIfWorkflowControlled(runContext);
    if (!scan?.ok) {
      const latestTab = await chrome.tabs.get(tab.id).catch(() => null);
      const currentUrl = latestTab?.pendingUrl || latestTab?.url || "";
      throwIfLinkedInAccessInterrupted(currentUrl, {
        expectedUrl: CONNECTIONS_URL,
        stage: "LinkedIn connections page",
      });
      if (!sameLinkedInDocument(currentUrl, CONNECTIONS_URL)) {
        throw new LinkedInAccessInterruptionError("page_unavailable", {
          pageUrl: currentUrl,
          expectedUrl: CONNECTIONS_URL,
          stage: "LinkedIn connections page",
        });
      }
      const channelUnavailable =
        isClosedMessageChannelError(scan?.error) ||
        /^(?:Could not establish connection\. Receiving end does not exist\.?|Extension context invalidated\.?)$/i.test(
          String(scan?.error || ""),
        );
      if (allowDeferredScan &&
          (scan?.errorCode === "CONNECTION_CARDS_UNAVAILABLE" || channelUnavailable)) {
        return {
          ...empty,
          deferred: true,
          error: scan.error || "The connections check could not finish. It will be tried again later.",
        };
      }
      throw new Error(scan?.error || "We couldn’t check new connections.");
    }
    reviewResult = await ScoutApi.authenticatedAction(
      "scouts:recordConnectionReview",
      {
        connections: scan.result.connections,
        top: scan.result.top,
      },
    );
    reviewResult = {
      ...reviewResult,
      connectionsScanned: scan.result.connections.length,
      lookbackDays: scan.result.lookbackDays || lookbackDays,
    };
    throwIfWorkflowControlled(runContext);
  } finally {
    clearActiveWorkflowTab(tab.id);
    if (!keepConnectionTab) {
      await chrome.tabs.remove(tab.id).catch(() => {});
    }
  }

  const contactLeads = collectContacts
    ? uniqueLeads([
        ...(plan.contactLeads || []),
        ...(reviewResult.acceptedLeads || []),
      ])
    : [];
  let contactsChecked = 0;
  let emailsCollected = 0;
  for (const lead of contactLeads) {
    throwIfWorkflowControlled(runContext);
    await updateActiveRunState(runContext, {
      phase: "reviewing_contacts",
      message: `Checking contact details for ${lead.fullName}...`,
      currentLead: {
        id: lead.id,
        fullName: lead.fullName,
        status: "accepted",
      },
    });
    const result = await collectAcceptedContact(lead, runContext).catch(async (error) => {
      if (isWorkflowControlError(error)) throw error;
      if (isLinkedInAccessInterruptionError(error) &&
          !["page_unavailable", "profile_link"].includes(error.kind)) throw error;
      await ScoutApi.authenticatedAction("scouts:reportError", {
        leadId: lead.id,
        message: cleanError(error),
        source: "accepted_contact",
      });
      return null;
    });
    if (!result) continue;
    contactsChecked += 1;
    if (result.email) emailsCollected += 1;
    throwIfWorkflowControlled(runContext);
  }
  return {
    reviewed: true,
    acceptedMatched: Number(reviewResult.matched || 0),
    contactsChecked,
    emailsCollected,
    connectionsScanned: Number(reviewResult.connectionsScanned || 0),
    lookbackDays: Number(reviewResult.lookbackDays || lookbackDays),
    connectionTabId: keepConnectionTab ? tab.id : null,
  };
}

async function readConnectionReviewLookbackDays() {
  const stored = await chrome.storage.local.get("connectionReviewLookbackDays");
  const value = Number(stored.connectionReviewLookbackDays);
  return ALLOWED_CONNECTION_REVIEW_LOOKBACK_DAYS.has(value)
    ? value
    : DEFAULT_CONNECTION_REVIEW_LOOKBACK_DAYS;
}

function checkAcceptedConnectionsManually() {
  if (manualConnectionReviewPromise) return manualConnectionReviewPromise;
  manualConnectionReviewPromise = runManualAcceptedConnectionReview().finally(
    () => {
      manualConnectionReviewPromise = null;
    },
  );
  return manualConnectionReviewPromise;
}

async function runManualAcceptedConnectionReview() {
  if (workflowPromise) {
    throw new Error(
      "Finish or pause today’s automation before checking accepted connections manually.",
    );
  }
  await ensureAutoLeadRunState();
  const state = await readAutoLeadRunState();
  if (ACTIVE_RUN_STATUSES.has(state.status)) {
    throw new Error(
      "Today’s automation is still in progress. Pause it before checking accepted connections manually.",
    );
  }

  const dashboard = await ScoutApi.authenticatedAction("scouts:getDashboard");
  if (!dashboard.settings?.onboardingCompleted) {
    throw new Error("Finish setup before checking accepted connections.");
  }

  const runContext = {
    runId: createRunId(),
    resume: false,
    progress: defaultRunProgress(),
    automationWindowId: null,
    automationHomeTabId: null,
    automationTabGroupId: null,
    connectionReviewTabId: null,
  };
  const previousStateToClose = state.automationWindowId ? state : null;
  const automationContext = await prepareAutomationWindow(
    runContext,
    null,
    previousStateToClose,
  );
  Object.assign(runContext, automationContext);
  activeAutomationWindowId = runContext.automationWindowId;
  try {
    const result = await reviewAcceptedConnections(dashboard, runContext, {
      forceReview: true,
      keepConnectionTab: true,
      collectContacts: true,
    });
    // Keep the manual review button as the single daily LinkedIn check. Once
    // accepted connections have been reviewed, inspect Sent Invitations and
    // reject matching requests that have been pending for 30+ days.
    const rejectedRequests = await autoWithdrawOldRequests(runContext);
    if (result.connectionTabId) {
      await chrome.tabs.update(result.connectionTabId, { active: true }).catch(
        () => {},
      );
    }
    await updateBadge();
    const latestState = await readAutoLeadRunState();
    const canCloseReviewWindow =
      !workflowPromise && !ACTIVE_RUN_STATUSES.has(latestState.status);
    const reviewWindowClosed = canCloseReviewWindow
      ? await closeManagedAutomationWindow(
          runContext.automationWindowId,
          runContext.automationHomeTabId,
        ).catch(() => false)
      : false;
    const completedReview = {
      ...result,
      rejectedCount: Number(rejectedRequests.withdrawnCount || 0),
      rejectedLeads: rejectedRequests.withdrawnLeads || [],
      connectionTabId: reviewWindowClosed ? null : result.connectionTabId,
      checkedAt: Date.now(),
      connectionWindowKeptOpen: !reviewWindowClosed,
    };
    await chrome.storage.local.set({
      lastAcceptedConnectionReview: completedReview,
    });
    return completedReview;
  } catch (error) {
    await chrome.storage.local.set({
      lastAcceptedConnectionReview: {
        checkedAt: Date.now(),
        error: cleanError(error),
      },
    });
    throw error;
  } finally {
    activeWorkflowTabId = null;
    activeAutomationWindowId = null;
  }
}

async function autoWithdrawOldRequests(runContext = null) {
  if (runContext) throwIfWorkflowControlled(runContext);
  const scoutOps = await ScoutApi.authenticatedAction(
    "scouts:getScoutOperations",
    {},
  ).catch(() => null);
  const oldRequests = scoutOps?.oldRequests || [];

  const tab = runContext
    ? await createAutomationTab(runContext, SENT_INVITATIONS_URL)
    : await chrome.tabs.create({ url: SENT_INVITATIONS_URL, active: true });
  if (!tab?.id) {
    throw new Error("We couldn’t open your LinkedIn sent invitations.");
  }

  try {
    await waitForTabComplete(tab.id, {
      expectedUrl: SENT_INVITATIONS_URL,
      stage: "LinkedIn sent invitations page",
    });
    if (runContext) throwIfWorkflowControlled(runContext);
    if (runContext) await waitForAutomationContentScript(runContext, tab.id);
    else await waitForContentScript(tab.id);

    const withdrawMessage = {
      type: "WITHDRAW_OLD_SENT_INVITATIONS",
      options: { dbLeads: oldRequests },
    };
    const withdrawResponse = runContext
      ? await sendAutomationMessageToTab(runContext, tab.id, withdrawMessage)
      : await sendMessageToTab(tab.id, withdrawMessage);

    if (!withdrawResponse?.ok) {
      if (runContext) throwIfWorkflowControlled(runContext);
      throw new Error(
        withdrawResponse?.error || "Failed to withdraw old invitations.",
      );
    }

    const sentInvitations = withdrawResponse.result?.invitations || [];
    const sentSync = await ScoutApi.authenticatedAction(
      "scouts:recordSentInvitationReview",
      { invitations: sentInvitations },
    );
    const withdrawnList = withdrawResponse.result?.withdrawn || [];
    for (const item of withdrawnList) {
      if (item.leadId) {
        await ScoutApi.authenticatedAction("scouts:markOldRequestWithdrawn", {
          leadId: item.leadId,
        }).catch((err) => {
          console.warn("Failed to mark lead withdrawn in DB:", item.leadId, err);
        });
      }
    }
    if (runContext) throwIfWorkflowControlled(runContext);

    await updateBadge();
    return {
      withdrawnCount: withdrawnList.length,
      withdrawnLeads: withdrawnList,
      sentInvitationsScanned: sentInvitations.length,
      sentLeadsMatched: Number(sentSync?.matched || 0),
      sentLeadsUpdated: Number(sentSync?.updated || 0),
    };
  } finally {
    if (runContext) clearActiveWorkflowTab(tab.id);
    await chrome.tabs.remove(tab.id).catch(() => {});
  }
}

async function collectAcceptedContact(lead, runContext) {
  const requestedProfileUrl = normalizeLinkedInProfileUrl(lead.profileUrl);
  const tab = await createAutomationTab(runContext, requestedProfileUrl);
  if (!tab?.id) throw new Error("We couldn’t open this LinkedIn profile.");
  try {
    await waitForTabComplete(tab.id, {
      expectedUrl: requestedProfileUrl,
      stage: `${lead.fullName || "This lead"}'s LinkedIn profile`,
    });
    throwIfWorkflowControlled(runContext);
    const profileUrl = await waitForResolvedLinkedInProfileUrl(
      tab.id,
      requestedProfileUrl,
      30_000,
      lead.fullName,
    );
    await waitForAutomationContentScript(runContext, tab.id);
    const contact = await sendAutomationMessageToTab(
      runContext,
      tab.id,
      {
        type: "EXTRACT_CONTACT_INFO",
        options: { expectedProfileUrl: profileUrl },
      },
      {
        retryOnClosedChannel: true,
        recoveryMessage: `LinkedIn refreshed while checking contact details for ${lead.fullName}. Reconnecting safely...`,
      },
    );
    throwIfWorkflowControlled(runContext);
    if (!contact?.ok) {
      throw new Error(contact?.error || "We couldn’t read the contact info.");
    }
    return ScoutApi.authenticatedAction("scouts:recordContactInfo", {
      leadId: lead.id,
      profileUrl,
      email: contact.result.email || null,
    });
  } finally {
    clearActiveWorkflowTab(tab.id);
    await chrome.tabs.remove(tab.id).catch(() => {});
  }
}

async function collectKnownConnectionContact(
  lead,
  profileUrl,
  tab,
  runContext,
  progress,
) {
  const knownConnection = await ScoutApi.authenticatedAction(
    "scouts:recordKnownConnection",
    {
      leadId: lead.id,
      profileUrl,
    },
  );
  try {
    if (knownConnection.email) {
      await updateRunProgress(runContext, progress, {
        phase: "working_leads",
        message: `Already connected to ${lead.fullName}; the email was already in the database.`,
        currentLead: {
          id: lead.id,
          fullName: lead.fullName,
          status: knownConnection.status,
        },
      });
      return {
        ...knownConnection,
        source: "database",
      };
    }

    await waitForAutomationContentScript(runContext, tab.id);
    const contact = await sendAutomationMessageToTab(
      runContext,
      tab.id,
      {
        type: "EXTRACT_CONTACT_INFO",
        options: { expectedProfileUrl: profileUrl },
      },
      {
        retryOnClosedChannel: true,
        recoveryMessage: `LinkedIn refreshed while checking contact details for ${lead.fullName}. Reconnecting safely...`,
      },
    );
    throwIfWorkflowControlled(runContext);
    if (!contact?.ok) {
      throw new Error(
        contact?.error || "We couldn’t read this connected lead’s contact info.",
      );
    }

    const saved = await ScoutApi.authenticatedAction("scouts:recordContactInfo", {
      leadId: lead.id,
      profileUrl,
      email: contact.result.email || null,
    });
    await updateRunProgress(runContext, progress, {
      phase: "working_leads",
      message: saved.email
        ? `Already connected to ${lead.fullName}; the email was saved.`
        : `Already connected to ${lead.fullName}; no email was available in Contact info.`,
      currentLead: {
        id: lead.id,
        fullName: lead.fullName,
        status: saved.status,
      },
    });
    return {
      ...saved,
      source: "linkedin_contact_info",
    };
  } catch (error) {
    error.knownConnection = true;
    throw error;
  }
}

async function inspectConnectionStatus(runContext, tabId, lead, profileUrl) {
  const message = {
    type: "INSPECT_CONNECTION_STATUS",
    options: {
      expectedProfileName: lead.fullName,
      expectedProfileUrl: profileUrl,
    },
  };
  let response = null;
  for (let attempt = 0; attempt < CONNECTION_STATE_MAX_ATTEMPTS; attempt++) {
    response = await sendAutomationMessageToTab(runContext, tabId, message, {
      retryOnClosedChannel: true,
      recoveryMessage: `LinkedIn refreshed while checking ${lead.fullName}. Reconnecting safely...`,
    });
    const unavailable =
      response?.ok &&
      response.result?.checked &&
      response.result?.connectionState === "unavailable";
    if (!unavailable || attempt === CONNECTION_STATE_MAX_ATTEMPTS - 1) {
      return response;
    }

    const nextAttempt = attempt + 2;
    await updateActiveRunState(runContext, {
      message: `LinkedIn's profile actions are still loading for ${lead.fullName}. Waiting, then retrying (${nextAttempt} of ${CONNECTION_STATE_MAX_ATTEMPTS})...`,
    });
    throwIfWorkflowControlled(runContext);
    await sleep(CONNECTION_STATE_RETRY_DELAYS_MS[attempt] || 2_000);
    await chrome.tabs.reload(tabId);
    await waitForTabComplete(tabId, {
      expectedUrl: profileUrl,
      stage: `${lead.fullName || "This lead"}'s connection actions`,
    });
    await waitForAutomationContentScript(runContext, tabId);
    throwIfWorkflowControlled(runContext);
  }
  return response;
}

async function recordPendingConnectionRequest(
  lead,
  profileUrl,
  runContext,
  progress,
  engagedCount = 0,
  engagementSkipped = false,
  engagementSkipReason = null,
) {
  await ScoutApi.authenticatedAction("scouts:recordPendingConnectionRequest", {
    leadId: lead.id,
    profileUrl,
  });
  await updateRunProgress(runContext, progress, {
    phase: "working_leads",
    message: `A connection request to ${lead.fullName} was already pending. It was synced without sending a duplicate.`,
    currentLead: {
      id: lead.id,
      fullName: lead.fullName,
      status: "connection_requested",
    },
  });
  return {
    leadId: lead.id,
    leadName: lead.fullName,
    status: "connection_requested",
    profileUrl,
    engagedCount,
    engagementSkipped,
    engagementSkipReason,
    requestAlreadyPending: true,
  };
}

async function runPostEngagementWithRecovery(
  runContext,
  tabId,
  lead,
  profileUrl,
  automationOptions,
  progress,
) {
  const message = {
    type: "EXECUTE_POST_ENGAGEMENT",
    options: { ...automationOptions, profileUrl },
  };
  let response = await sendAutomationMessageToTab(runContext, tabId, message);
  if (!isClosedMessageChannelError(response?.error)) return response;

  const checkpoint = await ScoutApi.authenticatedAction(
    "scouts:getLeadAutomationCheckpoint",
    { leadId: lead.id },
  );
  const receiptKey = `callumCommentReceipts:${encodeURIComponent(automationOptions.expectedScout || "")}:${lead.id}`;
  const savedReceipt = (await chrome.storage.local.get(receiptKey))[receiptKey];
  const canResumePosts = savedReceipt?.owner === automationOptions.expectedScout && savedReceipt.complete === false;
  if (Number(checkpoint?.engagedCount || 0) > 0 && !canResumePosts) {
    const engagedCount = Math.min(
      Number(checkpoint.engagedCount),
      Number(automationOptions.postEngagements || checkpoint.engagedCount),
    );
    await updateRunProgress(runContext, progress, {
      phase: "engaging",
      message: `LinkedIn refreshed after ${engagedCount} post${engagedCount === 1 ? "" : "s"}. Continuing from the saved result...`,
    });
    return {
      ok: true,
      result: {
        engagedCount,
        totalProcessed: Number(automationOptions.postEngagements || engagedCount),
        partial: engagedCount < Number(automationOptions.postEngagements || engagedCount),
        recoveredAfterRefresh: true,
        leadLanguageDecision: automationOptions.requireLanguageFallback
          ? { status: "english", languageCode: "en", confidence: 0.8 }
          : {
              status: automationOptions.profileLanguageStatus || "english",
              languageCode: automationOptions.profileLanguageStatus === "english" ? "en" : "und",
              confidence: automationOptions.profileLanguageStatus === "english" ? 1 : 0,
            },
      },
    };
  }

  await updateRunProgress(runContext, progress, {
    phase: "engaging",
    message: `LinkedIn refreshed before any post was saved for ${lead.fullName}. Retrying once...`,
  });
  await waitForAutomationContentScript(runContext, tabId);
  response = await sendAutomationMessageToTab(runContext, tabId, message);
  if (isClosedMessageChannelError(response?.error)) {
    return {
      ok: false,
      error:
        "LinkedIn refreshed twice before any post could be confirmed. This lead was skipped safely.",
    };
  }
  return response;
}

function resolvePostEngagementOutcome(response) {
  if (!response?.ok) {
    return {
      engagedCount: 0,
      skipped: true,
      skipReason: cleanError(
        response?.error || "We couldn’t finish this lead’s posts.",
      ),
    };
  }

  const engagedCount = Math.max(
    0,
    Math.trunc(Number(response.result?.engagedCount || 0)),
  );
  const skipped = Boolean(response.result?.skipped) || engagedCount < 1;
  return {
    engagedCount,
    skipped,
    skipReason: skipped || response.result?.skipReason
      ? cleanError(
          response.result?.skipReason || "No suitable comment was added.",
        )
      : null,
  };
}

async function executeConnectionRequestWithRecovery(
  runContext,
  tabId,
  lead,
  profileUrl,
  requestOptions,
  progress,
  engagedCount,
  engagementSkipped = false,
  engagementSkipReason = null,
) {
  const message = {
    type: "EXECUTE_CONNECTION_REQUEST",
    options: requestOptions,
  };
  const response = await sendAutomationMessageToTab(runContext, tabId, message);
  if (!isClosedMessageChannelError(response?.error)) {
    return { response, pendingResult: null };
  }

  await updateRunProgress(runContext, progress, {
    phase: "connecting",
    message: `LinkedIn refreshed while connecting to ${lead.fullName}. Checking whether the request is Pending...`,
  });
  await waitForAutomationContentScript(runContext, tabId);
  const inspection = await inspectConnectionStatus(
    runContext,
    tabId,
    lead,
    profileUrl,
  );
  if (inspection?.ok && inspection.result?.connectionState === "pending") {
    const pendingResult = await recordPendingConnectionRequest(
      lead,
      profileUrl,
      runContext,
      progress,
      engagedCount,
      engagementSkipped,
      engagementSkipReason,
    );
    return { response: { ok: true }, pendingResult };
  }

  // A visible Connect button does not prove that the earlier click failed:
  // LinkedIn may show stale actions while the invitation is being processed.
  // Never send a second invitation after losing the first response.
  return {
    response: {
      ok: false,
      error: UNCERTAIN_INVITATION_ERROR,
      requestOutcomeUncertain: true,
    },
    pendingResult: null,
  };
}

async function createPersonalizedConnectionNoteWithRetry(
  runContext,
  tabId,
  lead,
  profileUrl,
) {
  let lastError = null;
  for (let attempt = 1; attempt <= CONNECTION_NOTE_MAX_ATTEMPTS; attempt += 1) {
    throwIfWorkflowControlled(runContext);
    try {
      const extraction = await sendAutomationMessageToTab(
        runContext,
        tabId,
        {
          type: "EXTRACT_CONNECTION_NOTE_PROFILE",
          options: {
            expectedProfileUrl: profileUrl,
            expectedProfileName: String(lead.fullName || "").trim(),
          },
        },
        {
          retryOnClosedChannel: true,
          recoveryMessage: `LinkedIn refreshed while reading ${lead.fullName}. Reconnecting safely...`,
        },
      );
      if (!extraction?.ok) {
        throw new Error(extraction?.error || "We couldn’t read this profile.");
      }
      const profile = extraction.result || {};
      const result = await ScoutApi.authenticatedAction(
        "scouts:draftConnectionNote",
        {
          leadId: lead.id,
          profile: {
            fullName: profile.fullName || null,
            headline: profile.headline || null,
            location: profile.location || null,
            about: profile.about || null,
            currentRole: profile.currentRole || null,
            currentCompany: profile.currentCompany || null,
          },
        },
      );
      const note = String(result?.note || "").trim();
      if (!note || note.length > 300) {
        throw new Error("The personal connection note was empty or too long.");
      }
      await sendAutomationMessageToTab(runContext, tabId, {
        type: "SHOW_AUTOMATION_STATUS",
        status: "Personal connection note ready. Continuing with this lead...",
      }).catch(() => {});
      return note;
    } catch (error) {
      if (isWorkflowControlError(error) || isRecoverableServiceError(error) ||
          isLinkedInAccessInterruptionError(error)) throw error;
      lastError = error;
      if (attempt < CONNECTION_NOTE_MAX_ATTEMPTS) {
        await sendAutomationMessageToTab(runContext, tabId, {
          type: "SHOW_AUTOMATION_STATUS",
          status: "The personal note needs another try. Retrying now...",
        }).catch(() => {});
        await sleep(CONNECTION_NOTE_RETRY_DELAY_MS);
      }
    }
  }
  throw lastError || new Error("The personal connection note could not be created.");
}

async function checkLeadProfileLanguage(
  runContext,
  tabId,
  lead,
  profileUrl,
) {
  await sendAutomationMessageToTab(runContext, tabId, {
    type: "SHOW_AUTOMATION_STATUS",
    status: "Checking that this profile is in English...",
  }).catch(() => {});
  let profile = null;
  try {
    const extraction = await sendAutomationMessageToTab(
      runContext,
      tabId,
      {
        type: "EXTRACT_CONNECTION_NOTE_PROFILE",
        options: {
          expectedProfileUrl: profileUrl,
          expectedProfileName: String(lead.fullName || "").trim(),
          languageCheckOnly: true,
        },
      },
      {
        retryOnClosedChannel: true,
        recoveryMessage: `LinkedIn refreshed during ${lead.fullName}'s language check. Reconnecting safely...`,
      },
    );
    if (extraction?.ok) profile = extraction.result || {};
  } catch (error) {
    if (isWorkflowControlError(error) || isLinkedInAccessInterruptionError(error)) throw error;
    profile = null;
  }
  const sample = [profile?.headline, profile?.currentRole, profile?.about]
    .map((value) => String(value || "").trim())
    .filter(Boolean)
    .join("\n")
    .slice(0, 8_000);
  if (sample.length < 30) {
    return {
      status: "uncertain",
      languageCode: "und",
      confidence: 0,
      cached: false,
    };
  }
  const response = await ScoutApi.authenticatedAction(
    "scouts:classifyLanguages",
    {
      leadId: lead.id,
      context: "profile",
      samples: [{ id: "profile", text: sample }],
    },
  );
  const decision = response?.results?.[0] || {
    status: "uncertain",
    languageCode: "und",
    confidence: 0,
  };
  if (decision.status !== "uncertain") {
    await ScoutApi.authenticatedAction("scouts:recordLeadLanguageDecision", {
      leadId: lead.id,
      status: decision.status,
      languageCode: decision.languageCode,
      confidence: Number(decision.confidence || 0),
      source: "profile",
    });
  }
  return { ...decision, cached: Boolean(response?.cached) };
}

async function recordRecentPostLanguageDecision(lead, decision) {
  return ScoutApi.authenticatedAction("scouts:recordLeadLanguageDecision", {
    leadId: lead.id,
    status: decision?.status === "english" ? "english" : "uncertain",
    languageCode:
      decision?.status === "english" ? decision.languageCode || "en" : "und",
    confidence: Number(decision?.confidence || 0),
    source: "recent_posts",
  });
}

async function runLeadWorkflow(lead, settings, usage, runContext, progress) {
  let workflowTabId = null;
  let connectionReserved = false;
  let requestSubmitted = false;
  let connectionAttemptStarted = false;
  let connectionPersistencePending = false;
  let completedEngagementCount = 0;
  let engagementSkipped = false;
  let engagementSkipReason = null;
  let resolvedProfileUrl = lead.linkedinUrl;
  let knownConnectionDetected = false;
  let profileLanguage = {
    status: "uncertain",
    languageCode: "und",
    confidence: 0,
  };
  try {
    throwIfWorkflowControlled(runContext);
    let includeNote = Boolean(settings.includeNote && settings.linkedinPremium);
    throwIfWorkflowControlled(runContext);

    const requestedProfileUrl = normalizeLinkedInProfileUrl(lead.linkedinUrl);
    const localSettings = await chrome.storage.local.get([
      "validateBeforeCommenting",
    ]);
    const postEngagements = Math.min(
      clampInteger(settings.postEngagements ?? 3, 1, 10),
      clampInteger(usage.engagementRemaining ?? 0, 0, 250),
    );
    const scoutAuth = await ScoutApi.getAuth();
    const receiptKey = `callumCommentReceipts:${encodeURIComponent(scoutAuth?.username || "")}:${lead.id}`;
    const storedReceipt = (await chrome.storage.local.get(receiptKey))[receiptKey];
    const hasIncompleteComments = Boolean(
      storedReceipt?.owner === scoutAuth?.username && storedReceipt.complete === false,
    );
    const needsEngagement = lead.status !== "engaged" || hasIncompleteComments;
    const automationOptions = {
      leadId: lead.id,
      postEngagements,
      postEngagementTarget: clampInteger(settings.postEngagements ?? 3, 1, 10),
      expectedScout: scoutAuth?.username,
      validateBeforeCommenting:
        localSettings.validateBeforeCommenting ?? false,
      includeNote: false,
      invitationNote: "",
    };

    const tab = await createAutomationTab(runContext, requestedProfileUrl);
    workflowTabId = tab.id;
    await waitForTabComplete(tab.id, {
      expectedUrl: requestedProfileUrl,
      stage: `${lead.fullName || "This lead"}'s LinkedIn profile`,
    });
    throwIfWorkflowControlled(runContext);
    const profileUrl = await waitForResolvedLinkedInProfileUrl(
      tab.id,
      requestedProfileUrl,
      30_000,
      lead.fullName,
    );
    resolvedProfileUrl = profileUrl;
    await ScoutApi.authenticatedAction("scouts:recordProfileVisit", {
      leadId: lead.id,
      resolvedLinkedinUrl: profileUrl,
    });
    throwIfWorkflowControlled(runContext);

    await waitForAutomationContentScript(runContext, tab.id);
    profileLanguage = await checkLeadProfileLanguage(
      runContext,
      tab.id,
      lead,
      profileUrl,
    );
    throwIfWorkflowControlled(runContext);
    if (profileLanguage.status === "non_english") {
      const languageLabel = profileLanguage.languageCode === "und"
        ? "another language"
        : profileLanguage.languageCode.toUpperCase();
      await updateRunProgress(runContext, progress, {
        phase: "working_leads",
        message: `${lead.fullName} was skipped because the profile is not in English (${languageLabel}).`,
        currentLead: {
          id: lead.id,
          fullName: lead.fullName,
          status: "skipped",
        },
      });
      return {
        leadId: lead.id,
        leadName: lead.fullName,
        status: "skipped",
        profileUrl,
        languageFiltered: true,
        languageStatus: "non_english",
        languageCode: profileLanguage.languageCode,
        engagedCount: 0,
      };
    }
    const connectionInspection = await inspectConnectionStatus(
      runContext,
      tab.id,
      lead,
      profileUrl,
    );
    throwIfWorkflowControlled(runContext);
    if (!connectionInspection?.ok) {
      throw new Error(
        connectionInspection?.error ||
          "We couldn’t check this lead’s LinkedIn connection status.",
      );
    }
    if (!connectionInspection.result?.checked) {
      throw new Error("We couldn’t confirm this lead’s LinkedIn connection status.");
    }
    if (!connectionInspection.result.connectAvailable) {
      if (connectionInspection.result.connectionState === "pending") {
        return recordPendingConnectionRequest(
          lead,
          profileUrl,
          runContext,
          progress,
          0,
        );
      }
      if (connectionInspection.result.connectionState !== "connected") {
        const issue = new Error(
          "The connection state could not be confirmed. Nothing was sent for this lead.",
        );
        issue.code = "CONNECTION_STATE_UNCONFIRMED";
        await ScoutApi.authenticatedAction("scouts:recordConnectionInspectionFailure", {
          leadId: lead.id,
          extensionVersion: chrome.runtime.getManifest().version,
          connectionState: connectionInspection.result.connectionState || "unavailable",
          diagnostics: connectionInspection.result.diagnostics || null,
        }).catch((diagnosticError) => {
          console.warn("Could not record connection inspection diagnostics:", cleanError(diagnosticError));
        });
        throw issue;
      }
      const fallback = await collectKnownConnectionContact(
        lead,
        profileUrl,
        tab,
        runContext,
        progress,
      );
      return {
        leadId: lead.id,
        leadName: lead.fullName,
        status: fallback.status,
        profileUrl,
        email: fallback.email || null,
        emailSource: fallback.source,
        connectionAlreadyPresent: true,
        engagedCount: 0,
      };
    }
    if (includeNote && profileLanguage.status === "english") {
      try {
        automationOptions.invitationNote =
          await createPersonalizedConnectionNoteWithRetry(
            runContext,
            tab.id,
            lead,
            profileUrl,
          );
        automationOptions.includeNote = true;
      } catch (error) {
        if (isWorkflowControlError(error) || isRecoverableServiceError(error) ||
            isLinkedInAccessInterruptionError(error)) throw error;
        includeNote = false;
        automationOptions.includeNote = false;
        console.warn(
          `Personal connection note skipped for ${lead.fullName || lead.id}:`,
          cleanError(error),
        );
        await sendAutomationMessageToTab(runContext, tab.id, {
          type: "SHOW_AUTOMATION_STATUS",
          status:
            "A personal note could not be created after two tries. The connection request will still continue without a note.",
        }).catch(() => {});
      }
    }
    let engagementResponse = {
      ok: true,
      result: {
        engagedCount: 0,
        resumedAfterEngagement: true,
        leadLanguageDecision: profileLanguage,
      },
    };
    const needsLanguageFallback = profileLanguage.status === "uncertain";
    if (needsEngagement && postEngagements < 1 && !needsLanguageFallback && !hasIncompleteComments) {
      engagementSkipped = true;
      engagementSkipReason = "The post limit has been reached for today.";
    } else if (needsEngagement || needsLanguageFallback) {
      const recentActivityUrl = `${profileUrl}/recent-activity/all/`;
      try {
        await chrome.tabs.update(tab.id, { url: recentActivityUrl });
        await waitForTabComplete(tab.id, {
          expectedUrl: recentActivityUrl,
          stage: `${lead.fullName || "This lead"}'s recent activity`,
          timeoutMs: LINKEDIN_OPTIONAL_TAB_LOAD_TIMEOUT_MS,
        });
        throwIfWorkflowControlled(runContext);
        await waitForAutomationContentScript(runContext, tab.id);
        engagementResponse = await runPostEngagementWithRecovery(
          runContext,
          tab.id,
          lead,
          profileUrl,
          {
            ...automationOptions,
            postEngagements: needsEngagement ? postEngagements : 0,
            profileLanguageStatus: profileLanguage.status,
            requireLanguageFallback: needsLanguageFallback,
          },
          progress,
        );
        if (!engagementResponse?.ok) {
          throwIfWorkflowControlled(runContext);
        }
      } catch (error) {
        if (
          isWorkflowControlError(error) ||
          isLinkedInAccessInterruptionError(error) ||
          isRecoverableServiceError(error)
        ) {
          throw error;
        }
        engagementResponse = {
          ok: true,
          result: {
            engagedCount: 0,
            skipped: true,
            skipReason: `LinkedIn's recent activity page was skipped after it failed to load: ${cleanError(error)}`,
            leadLanguageDecision: profileLanguage,
          },
        };
      }
      if (!engagementResponse?.ok &&
          engagementResponse?.errorCode === "COMMENT_RECEIPT_STORAGE_FAILED" &&
          engagementResponse?.storageDiagnostics) {
        await ScoutApi.authenticatedAction("scouts:recordCommentStorageFailure", {
          leadId: lead.id,
          extensionVersion: chrome.runtime.getManifest().version,
          diagnostics: engagementResponse.storageDiagnostics,
        }).catch((diagnosticError) => {
          console.warn("Could not record comment storage diagnostics:", cleanError(diagnosticError));
        });
      }
      if (!engagementResponse?.ok && isRecoverableServiceError(engagementResponse?.error)) {
        throw new Error(engagementResponse.error);
      }
      const engagementOutcome = resolvePostEngagementOutcome(engagementResponse);
      completedEngagementCount = engagementOutcome.engagedCount;
      engagementSkipped = engagementOutcome.skipped;
      engagementSkipReason = engagementOutcome.skipReason;
      if (engagementSkipReason) {
        await ScoutApi.authenticatedAction("scouts:recordEngagementSkip", {
          leadId: lead.id, reason: engagementSkipReason,
        }).catch(() => {});
      }
      if (shouldReportEngagementProblem(engagementSkipReason)) {
        await ScoutApi.authenticatedAction("scouts:reportError", {
          leadId: lead.id,
          message: `Post engagement skipped safely: ${engagementSkipReason}`,
        }).catch(() => {});
      }
      if (isRecoverableServiceError(engagementSkipReason)) {
        throw new Error(engagementSkipReason);
      }
    }

    if (profileLanguage.status === "uncertain") {
      const fallbackDecision = engagementResponse?.result?.leadLanguageDecision;
      const languageRecord = await recordRecentPostLanguageDecision(
        lead,
        fallbackDecision,
      );
      if (languageRecord?.filtered) {
        await updateRunProgress(runContext, progress, {
          phase: "working_leads",
          message: `${lead.fullName} was parked because English could not be confirmed.`,
          currentLead: {
            id: lead.id,
            fullName: lead.fullName,
            status: "skipped",
          },
        });
        return {
          leadId: lead.id,
          leadName: lead.fullName,
          status: "skipped",
          profileUrl,
          languageFiltered: true,
          languageStatus: "uncertain",
          languageCode: "und",
          engagedCount: completedEngagementCount,
        };
      }
      profileLanguage = fallbackDecision;
    }

    await checkpointRun(runContext, progress, {
      phase: "connecting",
      message: engagementSkipped
        ? `No comment was added for ${lead.fullName}. Continuing to the connection request...`
        : `Posts finished for ${lead.fullName}. Preparing the connection request...`,
      currentLead: {
        id: lead.id,
        fullName: lead.fullName,
        status: completedEngagementCount > 0 ? "engaged" : "viewed",
      },
    });

    await chrome.tabs.update(tab.id, { url: profileUrl });
    await waitForTabComplete(tab.id, {
      expectedUrl: profileUrl,
      stage: `${lead.fullName || "This lead"}'s profile before the connection request`,
    });
    throwIfWorkflowControlled(runContext);
    await waitForAutomationContentScript(runContext, tab.id);
    await ScoutApi.authenticatedAction("scouts:reserveConnectionRequest", {
      leadId: lead.id,
    });
    connectionReserved = true;
    throwIfWorkflowControlled(runContext);
    connectionAttemptStarted = true;
    const connectionAttempt = await executeConnectionRequestWithRecovery(
      runContext,
      tab.id,
      lead,
      profileUrl,
      {
        expectedProfileName: lead.fullName,
        expectedProfileUrl: profileUrl,
        includeNote: automationOptions.includeNote,
        invitationNote: automationOptions.invitationNote,
      },
      progress,
      completedEngagementCount,
      engagementSkipped,
      engagementSkipReason,
    );
    if (connectionAttempt.pendingResult) {
      requestSubmitted = true;
      connectionReserved = false;
      return connectionAttempt.pendingResult;
    }
    const connectResponse = connectionAttempt.response;
    if (!connectResponse?.ok) {
      throwIfWorkflowControlled(runContext);
      const connectionError = new Error(
        connectResponse?.error || "We couldn’t send the connection request.",
      );
      connectionError.requestOutcomeUncertain =
        connectResponse?.requestOutcomeUncertain === true ||
        connectResponse?.requestAttempted === true;
      throw connectionError;
    }
    if (connectResponse.result?.confirmationPending === true) {
      const connectionError = new Error(UNCERTAIN_INVITATION_ERROR);
      connectionError.requestOutcomeUncertain = true;
      throw connectionError;
    }
    requestSubmitted = true;
    connectionPersistencePending = true;
    await completeConnectionRequestWithRetry({
      leadId: lead.id,
      profileUrl,
    });
    connectionPersistencePending = false;
    await updateRunProgress(runContext, progress, {
      phase: "working_leads",
      message: `Connection request sent to ${lead.fullName}.`,
      currentLead: {
        id: lead.id,
        fullName: lead.fullName,
        status: "connection_requested",
      },
    });
    return {
      leadId: lead.id,
      leadName: lead.fullName,
      status: "connection_requested",
      profileUrl,
      engagedCount: completedEngagementCount,
      engagementSkipped,
      engagementSkipReason,
      connectionNoteAdded: automationOptions.includeNote,
    };
  } catch (error) {
    const message = cleanError(error);
    knownConnectionDetected =
      knownConnectionDetected || error?.knownConnection === true;
    const requestOutcomeUncertain = error?.requestOutcomeUncertain === true ||
      (connectionAttemptStarted && isLinkedInAccessInterruptionError(error));
    if (connectionReserved && !requestSubmitted && !requestOutcomeUncertain) {
      await ScoutApi.authenticatedAction("scouts:releaseConnectionRequest", {
        leadId: lead.id,
      }).catch(() => {});
    }
    if (isLinkedInAccessInterruptionError(error)) {
      // A lost page during request submission may hide whether LinkedIn sent
      // the invitation. Never queue an automatic retry in that state.
      error.requestOutcomeUncertain = requestOutcomeUncertain;
      await ScoutApi.authenticatedAction("scouts:reportError", { leadId: lead.id, message }).catch(() => {});
      throw error;
    }
    const requestedControl = getRequestedWorkflowControl(runContext);
    if (isWorkflowControlError(error) || requestedControl) {
      if (requestSubmitted && connectionPersistencePending) {
        const alreadyRecorded = progress.results.some(
          (result) => result?.leadId === lead.id,
        );
        progress.pendingConnectionRequests = upsertPendingConnectionRequest(
          progress.pendingConnectionRequests,
          {
            leadId: lead.id,
            leadName: lead.fullName,
            profileUrl: resolvedProfileUrl,
            confirmedAt: Date.now(),
          },
        );
        if (!alreadyRecorded) {
          progress.requestsSent += 1;
          progress.processedLeads += 1;
          progress.results.push({
            leadId: lead.id,
            leadName: lead.fullName,
            status: "connection_requested_pending_sync",
            profileUrl: resolvedProfileUrl,
            engagedCount: completedEngagementCount,
          });
        }
        await updateRunProgress(runContext, progress, {
          message:
            "Paused safely after sending the connection request. Resume will continue with the next lead while it syncs.",
          currentLead: null,
        });
      }
      throw isWorkflowControlError(error)
        ? error
        : new WorkflowControlError(requestedControl);
    }
    if (workflowTabId) {
      const feedback = requestSubmitted
        ? {
            type: "SHOW_AUTOMATION_STATUS",
            status:
              "Connection request sent. Callum Scout will finish syncing it automatically.",
          }
        : { type: "SHOW_AUTOMATION_ERROR", error: message };
      await sendAutomationMessageToTab(
        runContext,
        workflowTabId,
        feedback,
      ).catch(() => {});
    }
    const workflowError = new Error(message);
    workflowError.code = error?.code || null;
    workflowError.requestSubmitted = requestSubmitted;
    workflowError.persistencePending = connectionPersistencePending;
    workflowError.profileUrl = resolvedProfileUrl;
    workflowError.engagedCount = completedEngagementCount;
    workflowError.knownConnection = knownConnectionDetected;
    workflowError.requestOutcomeUncertain = requestOutcomeUncertain;
    throw workflowError;
  } finally {
    if (workflowTabId) {
      clearActiveWorkflowTab(workflowTabId);
      await chrome.tabs.remove(workflowTabId).catch(() => {});
    }
  }
}

function uniqueLeads(leads) {
  const unique = new Map();
  for (const lead of leads) {
    if (lead?.id && !unique.has(lead.id)) unique.set(lead.id, lead);
  }
  return [...unique.values()];
}

function sendMessageToTab(tabId, message) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(response);
      }
    });
  });
}

function waitForTabComplete(
  tabId,
  {
    expectedUrl = null,
    stage = "LinkedIn page",
    timeoutMs = LINKEDIN_TAB_LOAD_TIMEOUT_MS,
    exactUrl = false,
  } = {},
) {
  return new Promise((resolve, reject) => {
    let settled = false;
    let timeout = null;
    let readinessProbe = null;
    let lastKnownUrl = "";
    let probing = false;
    let unreadableSince = null;
    const finish = (error) => {
      if (settled) return;
      settled = true;
      chrome.tabs.onUpdated.removeListener(listener);
      clearTimeout(timeout);
      clearTimeout(readinessProbe);
      if (error) reject(error);
      else resolve();
    };
    const probeReadiness = async () => {
      if (settled || probing) return;
      probing = true;
      clearTimeout(readinessProbe);
      try {
        const tab = await chrome.tabs.get(tabId);
        let currentUrl = tab.pendingUrl || tab.url || "";
        lastKnownUrl = currentUrl;
        throwIfLinkedInAccessInterrupted(currentUrl, { expectedUrl, stage });
        if (expectedUrl || linkedInPath(currentUrl)) {
          const pageInfo = await readLinkedInPageInfo(tabId);
          // The reply may belong to a document that navigated away while we
          // waited. Only the latest tab URL can establish an access redirect.
          const latestTab = await chrome.tabs.get(tabId);
          currentUrl = latestTab.pendingUrl || latestTab.url || "";
          lastKnownUrl = currentUrl;
          throwIfLinkedInAccessInterrupted(currentUrl, { expectedUrl, stage });
          if (
            pageInfo?.url &&
            sameLinkedInDocument(pageInfo.url, currentUrl) &&
            (!expectedUrl || (exactUrl ? sameLinkedInDocument(pageInfo.url, expectedUrl) : isExpectedLinkedInPage(pageInfo.url, expectedUrl)))
          ) {
            finish();
            return;
          }
          // Browser error pages can report status=complete and retain the
          // intended URL, but cannot answer our content-script heartbeat.
          if (latestTab.status === "complete" && !pageInfo?.url) {
            unreadableSince ??= Date.now();
            if (Date.now() - unreadableSince >= 15_000) {
              finish(new LinkedInAccessInterruptionError("page_unavailable", { pageUrl: currentUrl, expectedUrl, stage }));
              return;
            }
          } else unreadableSince = null;
        } else if (tab.status === "complete" && !expectedUrl) {
          finish();
          return;
        }
      } catch (error) {
        if (
          isLinkedInAccessInterruptionError(error) ||
          /no tab with id/i.test(cleanError(error))
        ) {
          finish(error);
          return;
        }
      } finally {
        probing = false;
      }
      if (!settled) {
        readinessProbe = setTimeout(
          probeReadiness,
          LINKEDIN_TAB_READY_PROBE_MS,
        );
      }
    };
    const listener = (id) => {
      if (id === tabId) void probeReadiness();
    };
    chrome.tabs.onUpdated.addListener(listener);
    timeout = setTimeout(
      () =>
        finish(
          new LinkedInAccessInterruptionError("page_unavailable", {
            stage, pageUrl: lastKnownUrl, expectedUrl,
          }),
        ),
      timeoutMs,
    );
    void probeReadiness();
  });
}

function sameLinkedInDocument(left, right) {
  try {
    const a = new URL(left), b = new URL(right);
    return a.protocol === "https:" && b.protocol === "https:" &&
      /(^|\.)linkedin\.com$/i.test(a.hostname) && /(^|\.)linkedin\.com$/i.test(b.hostname) &&
      a.pathname.replace(/\/+$/, "") === b.pathname.replace(/\/+$/, "");
  } catch { return false; }
}

async function readLinkedInPageInfo(tabId, expectedProfileName) {
  let timer;
  try {
    return await Promise.race([
      sendMessageToTab(tabId, { type: "GET_PAGE_INFO", expectedProfileName }),
      new Promise(resolve => { timer = setTimeout(() => resolve(null), 3_000); }),
    ]);
  } finally { clearTimeout(timer); }
}

function isExpectedLinkedInPage(actualValue, expectedValue) {
  try {
    const actual = new URL(String(actualValue));
    const expected = new URL(String(expectedValue));
    if (
      !/(^|\.)linkedin\.com$/i.test(actual.hostname) ||
      !/(^|\.)linkedin\.com$/i.test(expected.hostname)
    ) {
      return false;
    }
    const actualPath = actual.pathname.replace(/\/+$/, "");
    const expectedPath = expected.pathname.replace(/\/+$/, "");
    if (/^\/in\/[^/]+$/i.test(expectedPath)) {
      return /^\/in\/[^/]+$/i.test(actualPath);
    }
    if (/^\/in\/[^/]+\/recent-activity\/all$/i.test(expectedPath)) {
      return /^\/in\/[^/]+\/recent-activity\/all$/i.test(actualPath);
    }
    return actualPath === expectedPath;
  } catch {
    return false;
  }
}

function linkedInAccessInterruptionKind(value) {
  try {
    const url = new URL(String(value));
    if (!/(^|\.)linkedin\.com$/i.test(url.hostname)) return null;
    const path = url.pathname.replace(/\/+$/, "") || "/";
    if (/^\/checkpoint(?:\/|$)/i.test(path)) return "checkpoint";
    if (
      /^\/(?:authwall|login|uas\/login|signup)(?:\/|$)/i.test(path)
    ) {
      return "login";
    }
    return null;
  } catch {
    return null;
  }
}

function throwIfLinkedInAccessInterrupted(value, details = {}) {
  const kind = linkedInAccessInterruptionKind(value);
  if (kind) throw new LinkedInAccessInterruptionError(kind, { ...details, pageUrl: value });
}

function shouldReportEngagementProblem(reason) {
  return /couldn(?:'|’)t|could not|did not|failed|not confirm|not become ready|refreshed|message channel|unavailable/i.test(
    String(reason || ""),
  );
}

function linkedInPath(value) {
  try {
    const url = new URL(String(value));
    return /(^|\.)linkedin\.com$/i.test(url.hostname)
      ? url.pathname
      : "";
  } catch {
    return "";
  }
}

async function waitForContentScript(tabId, timeoutMs = 20_000) {
  const deadline = Date.now() + timeoutMs;
  let currentUrl = "";
  while (Date.now() < deadline) {
    const tab = await chrome.tabs.get(tabId);
    currentUrl = tab.pendingUrl || tab.url || "";
    throwIfLinkedInAccessInterrupted(currentUrl, { stage: "Reconnecting to LinkedIn page" });
    const response = await readLinkedInPageInfo(tabId);
    const latestTab = await chrome.tabs.get(tabId);
    currentUrl = latestTab.pendingUrl || latestTab.url || "";
    throwIfLinkedInAccessInterrupted(currentUrl, { stage: "Reconnecting to LinkedIn page" });
    if (sameLinkedInDocument(response?.url, currentUrl)) return response;
    await sleep(250);
  }
  throw new LinkedInAccessInterruptionError("page_unavailable", { pageUrl: currentUrl, stage: "Reconnecting to LinkedIn page" });
}

async function waitForResolvedLinkedInProfileUrl(
  tabId,
  requestedProfileUrl,
  timeoutMs = 30_000,
  expectedProfileName = "",
) {
  const requestedSlug = linkedInProfileSlug(requestedProfileUrl);
  const mustRedirect = isOpaqueLinkedInProfileSlug(requestedSlug);
  const deadline = Date.now() + timeoutMs;
  let lastProfileUrl = "";
  let lastUrlChangeAt = Date.now();
  while (Date.now() < deadline) {
    const tab = await chrome.tabs.get(tabId);
    const currentUrl = tab.pendingUrl || tab.url || "";
    throwIfLinkedInAccessInterrupted(currentUrl, { expectedUrl: requestedProfileUrl, stage: "Resolving LinkedIn profile" });
    const currentProfileUrl = tryNormalizeLinkedInProfileUrl(currentUrl);
    if (currentProfileUrl && currentProfileUrl !== lastProfileUrl) {
      lastProfileUrl = currentProfileUrl;
      lastUrlChangeAt = Date.now();
    }
    if (currentProfileUrl && Date.now() - lastUrlChangeAt >= 1_000) {
      const currentSlug = linkedInProfileSlug(currentProfileUrl);
      if (!mustRedirect || !isOpaqueLinkedInProfileSlug(currentSlug)) return currentProfileUrl;
      const page = await readLinkedInPageInfo(tabId, expectedProfileName);
      const latestTab = await chrome.tabs.get(tabId);
      const latestUrl = latestTab.pendingUrl || latestTab.url || "";
      throwIfLinkedInAccessInterrupted(latestUrl, { expectedUrl: requestedProfileUrl, stage: "Resolving LinkedIn profile" });
      const verified = tryNormalizeLinkedInProfileUrl(page?.resolvedProfileUrl);
      if (sameLinkedInDocument(page?.url, latestUrl) && verified &&
          !isOpaqueLinkedInProfileSlug(linkedInProfileSlug(verified))) {
        // Navigate to the observed own-profile link so every later identity
        // check and recent-activity URL uses the same verified page.
        await chrome.tabs.update(tabId, { url: verified });
        await waitForTabComplete(tabId, { expectedUrl: verified, exactUrl: true,
          timeoutMs: Math.max(1, deadline - Date.now()), stage: "Verified LinkedIn profile" });
        return verified;
      }
    }
    await sleep(250);
  }
  if (lastProfileUrl && !mustRedirect) return lastProfileUrl;
  throw new LinkedInAccessInterruptionError("profile_link", { pageUrl: lastProfileUrl, expectedUrl: requestedProfileUrl, stage: "Resolving LinkedIn profile" });
}

function normalizeLinkedInProfileUrl(value) {
  let url;
  try {
    url = new URL(String(value));
  } catch {
    throw new Error("This lead’s LinkedIn link does not work.");
  }
  if (url.protocol !== "https:" || !/(^|\.)linkedin\.com$/i.test(url.hostname)) {
    throw new Error("This lead’s LinkedIn link does not work.");
  }
  const match = url.pathname.match(/^\/in\/([^/]+)/i);
  if (!match) throw new Error("This lead’s LinkedIn link does not work.");
  return `https://www.linkedin.com/in/${match[1]}`;
}

function tryNormalizeLinkedInProfileUrl(value) {
  try {
    return normalizeLinkedInProfileUrl(value);
  } catch {
    return null;
  }
}

function linkedInProfileSlug(value) {
  return new URL(value).pathname.split("/").filter(Boolean)[1] || "";
}

function isOpaqueLinkedInProfileSlug(value) {
  return /^AC[ow][A-Za-z0-9_-]{15,}$/.test(String(value));
}

function clampInteger(value, minimum, maximum) {
  const number = Math.trunc(Number(value));
  return Math.max(
    minimum,
    Math.min(maximum, Number.isFinite(number) ? number : minimum),
  );
}

function cleanError(error) {
  return String(error instanceof Error ? error.message : error || "Something went wrong. Try again.")
    .replace(/^Error:\s*/i, "")
    .split("\n")[0];
}

function isRecoverableServiceError(error) {
  if (error?.retryable === true || ["AI_UNAVAILABLE", "AI_PENDING", "COMMENT_SYNC_PENDING"].includes(error?.code)) return true;
  return /writing service|scout AI hourly limit|AI check is already running|AI job (?:timed out|failed|was replaced)|Callum Scout isn.t ready|Callum Scout is not ready|lost its internet connection|We couldn.t reach Callum Scout|Callum Scout (?:took longer|did not respond)|gateway|fetch failed|failed to fetch|networkerror|service unavailable|comment progress could not be saved|comment was posted but its progress|your session changed|session expired|sign in is required|please sign in/i.test(cleanError(error));
}

function isClosedMessageChannelError(error) {
  return /(?:message channel|message port).*(?:closed|disconnected).*before.*response|asynchronous response.*channel closed/i.test(
    cleanError(error),
  );
}

function friendlyWorkflowError(error) {
  if (isClosedMessageChannelError(error)) {
    return "LinkedIn refreshed before Callum Scout could confirm the step. The saved run can be resumed safely.";
  }
  return cleanError(error);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function completeConnectionRequestWithRetry(args) {
  let lastError = null;
  for (const delayMs of CONNECTION_COMPLETION_RETRY_DELAYS_MS) {
    if (delayMs > 0) await sleep(delayMs);
    try {
      await ScoutApi.authenticatedAction(
        "scouts:completeConnectionRequest",
        args,
      );
      return;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError || new Error("The sent connection request could not be synced.");
}

function updateBadge(options = {}) {
  if (!badgeRefreshPromise) {
    badgeRefreshPromise = loadBadge(options).finally(() => { badgeRefreshPromise = null; });
  }
  return badgeRefreshPromise;
}

async function loadBadge({ cachedForMs = 0, dashboard: providedDashboard = null } = {}) {
  const auth = await ScoutApi.getAuth();
  if (!auth) {
    await chrome.action.setBadgeText({ text: "" });
    return null;
  }
  const cached = cachedForMs > 0
    ? await chrome.storage.local.get(["scoutDashboard", "scoutDashboardUpdatedAt"])
    : {};
  const age = Date.now() - Number(cached.scoutDashboardUpdatedAt || 0);
  const dashboard = providedDashboard || (
    cached.scoutDashboard?.scout?.username === auth.username && age >= 0 && age < cachedForMs
      ? cached.scoutDashboard
      : await ScoutApi.authenticatedAction("scouts:getDashboard")
  );
  await chrome.storage.local.set({
    scoutDashboard: dashboard,
    scoutDashboardUpdatedAt: dashboard === cached.scoutDashboard ? cached.scoutDashboardUpdatedAt : Date.now(),
  });
  await chrome.action.setBadgeBackgroundColor({ color: "#6347D8" });
  await chrome.action.setBadgeText({ text: compactNumber(dashboard.counts.fresh) });
  return dashboard;
}

function refreshBadgeInBackground() {
  void updateBadge({ cachedForMs: 300_000 }).catch(async (error) => {
    await chrome.action.setBadgeText({ text: "" }).catch(() => {});
    console.warn("Callum Scout badge refresh failed:", cleanError(error));
  });
}

function compactNumber(value) {
  const number = Number(value) || 0;
  if (number >= 1_000_000) return `${Math.floor(number / 100_000) / 10}M`;
  if (number >= 1_000) return `${Math.floor(number / 100) / 10}K`;
  return String(number);
}
// Chrome confirms availability from this installation's update channel. Never
// reload automatically here: a scout may have a live LinkedIn submission.
chrome.runtime.onUpdateAvailable.addListener(({ version }) => {
  void chrome.storage.local.set({ scoutAvailableUpdate: version });
});
